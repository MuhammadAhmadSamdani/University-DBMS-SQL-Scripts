USE master;

-- Check if the database exists
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'UniversityManagementSystem')
BEGIN
    -- Terminate all active connections
    ALTER DATABASE [UniversityManagementSystem] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    
    -- Drop the existing database
    DROP DATABASE UniversityManagementSystem;
END

-- Create a new database
CREATE DATABASE UniversityManagementSystem;

USE UniversityManagementSystem;


------------------------------------------------------------------------------------- TABLES

------------------------------------------------------------------------- ACADEMIC STRUCTURE

CREATE TABLE Departments(
Department_id INT PRIMARY KEY IDENTITY (1,1),
Department_name VARCHAR(50),
Department_code VARCHAR(10),
Head_of_department VARCHAR(50),
Description VARCHAR(MAX),
Email VARCHAR(50),
Department_Email AS (CONCAT(Email, '@gmail.com')),
Budget DECIMAL(18,2),
Research VARCHAR(MAX)
);

CREATE TABLE Degree_Program(
Degree_Program_id INT PRIMARY KEY IDENTITY (1,1),
Degree_Program_name VARCHAR(50),
Degree_Program_code VARCHAR(10),
Department_id INT,
Degree_level VARCHAR(20) CHECK (Degree_level IN ('Diploma', 'Bachelor', 'Master', 'PhD')),
Credits INT,
Total_credits_required AS (CONCAT(Credits,' ', 'Hours')), 
Duration INT,
Duration_years AS (CONCAT(Duration,' ' ,'Years')), 
Description VARCHAR(MAX),
FOREIGN KEY (Department_id) REFERENCES Departments(Department_id)
);

CREATE TABLE Course(
Course_id INT PRIMARY KEY IDENTITY (1,1),
Course_code VARCHAR(10),
Course_title VARCHAR(50),
Course_Type VARCHAR(20) CHECK (Course_Type IN ('Lab', 'Theory', 'Lab & Theory')),
Credits INT,
Total_credits_required AS (CONCAT(Credits,' ' , 'Hours')), 
Department_id INT,
Degree_Program_id INT,
Description VARCHAR(MAX),
Prerequisites VARCHAR(100),
FOREIGN KEY (Department_id) REFERENCES Departments(Department_id),
FOREIGN KEY (Degree_Program_id) REFERENCES Degree_Program(Degree_Program_id)
);


-------------------------------------------------------------- PERSONAL & UNIVERSITY DETAILS

CREATE TABLE Student_Personal_Details(
Student_personal_id INT PRIMARY KEY IDENTITY (1,1),
First_name VARCHAR(100),
Last_name VARCHAR(100),
Full_Name AS (First_Name + ' ' + Last_Name),  
Date_of_Birth DATE,
Gender VARCHAR(10),
Nationality VARCHAR(20),
CNIC VARCHAR(50),
Religion VARCHAR(20),
Permanent_Address VARCHAR(100),
Current_Address VARCHAR(100),
City VARCHAR(50),
Country VARCHAR(50),
Student_Personal_email VARCHAR(50),
Contact_Email AS (CONCAT(Student_Personal_email, '@gmail.com')),
Student_Personal_phone VARCHAR(10),
Contact_phone AS (CONCAT('+92', Student_Personal_phone)),
Emergency_contact_name VARCHAR(20),
Emergency_contact_relation VARCHAR(20),
Emergency_contact_phone VARCHAR(10),
Emergency_contact AS (CONCAT('+92', Emergency_contact_phone))
);

CREATE TABLE Guardian_Information(
Guardian_id INT PRIMARY KEY IDENTITY (1,1),
Student_personal_id INT,
First_name VARCHAR(100),
Last_name VARCHAR(100),
Full_Name AS (First_Name + ' ' + Last_Name),  
Relationship VARCHAR(20),
CNIC VARCHAR(50),
Email VARCHAR(50),
Contact_Email AS (CONCAT(Email, '@gmail.com')),
Phone_number VARCHAR(10),
Contact_phone AS (CONCAT('+92', Phone_number)),
Occupation VARCHAR(50),
Gaurdian_Address VARCHAR(100),
FOREIGN KEY (Student_personal_id) REFERENCES Student_Personal_Details(Student_personal_id)
);

CREATE TABLE Faculty_Personal_Details(
Faculty_personal_id INT PRIMARY KEY IDENTITY (1,1),
First_name VARCHAR(100),
Last_name VARCHAR(100),
Full_Name AS (First_Name + ' ' + Last_Name),  
Date_of_Birth DATE,
Gender VARCHAR(10),
Nationality VARCHAR(20),
CNIC VARCHAR(50),
Religion VARCHAR(20),
Address VARCHAR(100),
City VARCHAR(50),
Country VARCHAR(50),
Faculty_Personal_email VARCHAR(50),
Contact_Email AS (CONCAT(Faculty_Personal_email, '@gmail.com')),
Faculty_Personal_phone VARCHAR(10),
Contact_phone AS (CONCAT('+92', Faculty_Personal_phone)),
);

CREATE TABLE Faculty_University_Details(
Faculty_id INT PRIMARY KEY IDENTITY (1,1),
Faculty_personal_id INT,
Hire_date DATE,
Department_id INT,
Designation VARCHAR(50),
Status VARCHAR(20) CHECK (Status IN ('Active', 'On_leave', 'resigned', 'retired')),
FOREIGN KEY (Faculty_personal_id) REFERENCES Faculty_Personal_Details(Faculty_personal_id),
FOREIGN KEY (Department_id) REFERENCES Departments(Department_id)
);

CREATE TABLE Staff_Personal_Details(
Staff_personal_id INT PRIMARY KEY IDENTITY (1,1),
First_name VARCHAR(100),
Last_name VARCHAR(100),
Full_Name AS (First_Name + ' ' + Last_Name),  
Date_of_Birth DATE,
Gender VARCHAR(10),
Nationality VARCHAR(20),
CNIC VARCHAR(50),
Religion VARCHAR(20),
Address VARCHAR(100),
City VARCHAR(50),
Country VARCHAR(50),
Staff_Personal_email VARCHAR(50),
Contact_Email AS (CONCAT(Staff_Personal_email, '@gmail.com')),
Staff_Personal_phone VARCHAR(10),
Contact_phone AS (CONCAT('+92', Staff_Personal_phone)),
);

CREATE TABLE Staff_University_Details(
Staff_Personal_id INT,
Staff_id INT PRIMARY KEY IDENTITY (1,1),
Hire_date DATE,
Designation VARCHAR(50),
Staff_Type VARCHAR(20) CHECK (Staff_Type IN ('Administrator', 'Security', 'Medical', 'Cleaning', 'Gardener', 'Electrician', 'IT')),
Status VARCHAR(20) CHECK (Status IN ('Active', 'On_leave', 'resigned', 'retired')),
FOREIGN KEY (Staff_Personal_id) REFERENCES Staff_Personal_Details(Staff_Personal_id)
);

---------------------------------------------------------- SCHEDULING & TIMETABLE

CREATE TABLE Semester(
Semester_id INT PRIMARY KEY IDENTITY (1,1),
Semester_name VARCHAR(20),
Semester_code VARCHAR(10),
Academic_year INT,
Start_date DATE,
End_date DATE,
);

CREATE TABLE Building(
Building_id INT PRIMARY KEY IDENTITY (1,1),
Building_name VARCHAR(50),
Total_floors INT,
Floors AS (CONCAT(Total_floors, 'Floors')),
);

CREATE TABLE Section(
Section_id INT PRIMARY KEY IDENTITY (1,1),
Section_name CHAR,
Semester_id INT,
FOREIGN KEY (Semester_id) REFERENCES Semester(Semester_id),
);

CREATE TABLE Classroom(
Classroom_id INT PRIMARY KEY IDENTITY (1,1),
Room_number INT,
Building_id INT,
Capacity INT,
Room_capacity AS (CONCAT(Capacity, 'Seats')),
Facilitiies VARCHAR(50),
FOREIGN KEY (Building_id) REFERENCES Building(Building_id)
);

CREATE TABLE Time_slots(
Time_slot_id INT PRIMARY KEY IDENTITY (1,1),     
Day_of_week VARCHAR(10),
Start_time TIME,
End_time TIME
);

CREATE TABLE Timetable(
Timetable_id INT PRIMARY KEY IDENTITY (1,1), 
Section_id INT,                                                      -- View student timetable by joining  
Time_slot_id INT,                                                    -- Student_Enrollments ? Timetable ? TimeSlots
Classroom_id INT,              -- View faculty timetable by joining
Semester_id INT,
Degree_Program_id INT,
FOREIGN KEY (Semester_id) REFERENCES Semester(Semester_id),
FOREIGN KEY (Degree_Program_id) REFERENCES Degree_Program(Degree_Program_id),
FOREIGN KEY (Section_id) REFERENCES Section(Section_id),             -- Sections ? Timetable ? TimeSlots
FOREIGN KEY (Time_slot_id) REFERENCES Time_slots(Time_slot_id),     
FOREIGN KEY (Classroom_id) REFERENCES Classroom(Classroom_id)        
);

--------------------------------------------------------------- ADMISSION RECORDS

CREATE TABLE Admission_Application(
Application_id INT PRIMARY KEY IDENTITY (1,1),
Student_personal_id INT,
Degree_Program_id INT,
FSC INT,
FSC_Marks AS (CONCAT (FSC, '/1100')),
Is_eligible AS (CASE 
    WHEN FSC >= 550 THEN 'Eligible'
    ELSE 'Not Eligible'
END),
Application_date DATE,
Status VARCHAR(20) CHECK (Status IN ('Submitted', 'Under review', 'Accepted', 'Rejected')),
Comments VARCHAR(MAX),
FOREIGN KEY (Student_personal_id) REFERENCES Student_Personal_Details(Student_personal_id),
FOREIGN KEY (Degree_Program_id) REFERENCES Degree_Program(Degree_Program_id)
);

CREATE TABLE Student_University_Details(
Student_id INT PRIMARY KEY IDENTITY (1,1),
Student_personal_id INT,
Student_Roll_Number VARCHAR(20),
Student_Batch VARCHAR(20),
Department_id INT,
Degree_Program_id INT,
Current_Semester INT,
Section_id INT,
Uni_Email VARCHAR(50),
Student_University_Email AS (CONCAT(Uni_Email, '@uni.edu.pk')),
Status VARCHAR(20) CHECK (Status IN ('Active', 'In-active', 'Graduated', 'Drop out')),
FOREIGN KEY (Student_personal_id) REFERENCES Student_Personal_Details(Student_personal_id),
FOREIGN KEY (Department_id) REFERENCES Departments(Department_id),
FOREIGN KEY (Degree_Program_id) REFERENCES Degree_Program(Degree_Program_id),
FOREIGN KEY (Section_id) REFERENCES Section(Section_id)
);

-- NOTE: CREATE VIEW FOR ALUMNI (GRADUATED STUDENTS)

CREATE TABLE Enrolled_Students(
Enrollment_id INT PRIMARY KEY IDENTITY (1,1),
Student_id INT,
Degree_Program_id INT,
Semester_id INT,
Section_id INT,
Enrollment_date DATE,
FOREIGN KEY (Student_id) REFERENCES Student_University_Details(Student_id),
FOREIGN KEY (Degree_Program_id) REFERENCES Degree_Program(Degree_Program_id),
FOREIGN KEY (Semester_id) REFERENCES Semester(Semester_id),
FOREIGN KEY (Section_id) REFERENCES Section(Section_id),
);

-------------------------------------------------------------- EXAMINATION SYSTEM

CREATE TABLE Exam(
Exam_id INT PRIMARY KEY IDENTITY(1,1),
Exam_type VARCHAR(10) CHECK (Exam_type IN ('Mid-term', 'Final')),
Course_id INT,
Section_id INT,
Semester_id INT,
Total_marks INT,
Passing_marks INT,
Exam_date DATE,
Start_time DATETIME,
End_time DATETIME,
Classroom_id INT,
Invigilator_id INT,
Status VARCHAR(10) CHECK (Status IN ('Scheduled', 'Completed', 'Cancelled')),
FOREIGN KEY (Course_id) REFERENCES Course(Course_id),
FOREIGN KEY (Section_id) REFERENCES Section(Section_id),
FOREIGN KEY (Semester_id) REFERENCES Semester(Semester_id),
FOREIGN KEY (Classroom_id) REFERENCES Classroom(Classroom_id),
FOREIGN KEY (Invigilator_id) REFERENCES Faculty_University_Details(Faculty_id)
);

---------------------------------------------------------------- ACADEMIC RECORDS

CREATE TABLE Course_results(
Course_result_id INT PRIMARY KEY IDENTITY(1,1),
Enrollment_id INT,
Course_id INT,
Marks_obtained FLOAT,
Semester_id INT,
Grade CHAR,
FOREIGN KEY (Enrollment_id) REFERENCES Enrolled_Students(Enrollment_id),
FOREIGN KEY (Course_id) REFERENCES Course(Course_id),
FOREIGN KEY (Semester_id) REFERENCES Semester(Semester_id)
);

-- NOTE: CREATE VIEWS FOR SGPA AND CGPA

------------------------------------------------------------------------- LIBRARY

CREATE TABLE Book_Category(
Category_id INT PRIMARY KEY IDENTITY (1,1),
Category_name VARCHAR(100),
Description VARCHAR(MAX)
);

CREATE TABLE Library_Book(
Book_id INT PRIMARY KEY IDENTITY (1,1),
Title VARCHAR(100),
Author VARCHAR(100),
Publisher VARCHAR(100),
Publication_Year INT,
Edition VARCHAR(50),
Category_id INT,
Total_Copies INT,
Available_Copies INT,
Status VARCHAR(20) CHECK (Status IN ('Available', 'Lost', 'Damaged')),
FOREIGN KEY (Category_id) REFERENCES Book_Category(Category_id)
);

CREATE TABLE Book_Borrow(
Borrow_id INT PRIMARY KEY IDENTITY (1,1),
Book_id INT,
Student_id INT,
Borrowed_date DATE,
Return_date DATE,
FOREIGN KEY (Book_id) REFERENCES Library_Book(Book_id),
FOREIGN KEY (Student_id) REFERENCES Student_University_Details(Student_id),
);

CREATE TABLE Book_Returned(
Return_id INT PRIMARY KEY IDENTITY (1,1),
Returned_date DATE,
Borrow_id INT,
Book_id INT,
FOREIGN KEY (Book_id) REFERENCES Library_Book(Book_id),
FOREIGN KEY (Borrow_id) REFERENCES Book_Borrow(Borrow_id)
);

---------------------------------------------------------------- FINANCIAL SYSTEM

CREATE TABLE Scholarship(
Scholarship_id INT PRIMARY KEY IDENTITY (1,1),
Description VARCHAR(100),
Amount DECIMAL(10,2), -- EXAMPLE 50 FOR 50%
Criteria VARCHAR(100),
Application_deadline DATE
);

CREATE TABLE Student_Scholarship(
Student_Scholarship INT PRIMARY KEY IDENTITY (1,1),
Student_id INT,
Scholarship_id INT,
Application_date DATE,
Award_date DATE,
Status VARCHAR(20) CHECK (Status IN ('Awarded', 'Terminated')),
FOREIGN KEY (Student_id) REFERENCES Student_University_Details(Student_id),
FOREIGN KEY (Scholarship_id) REFERENCES Scholarship(Scholarship_id)
);

CREATE TABLE Fee(
Fee_id INT PRIMARY KEY IDENTITY (1,1),
Student_id INT,
Semester_id INT,
Fee_amount DECIMAL(10,2),
Final_Fee DECIMAL(10,2),
Due_date DATE,
FOREIGN KEY (Student_id) REFERENCES Student_University_Details(Student_id),
FOREIGN KEY (Semester_id) REFERENCES Semester(Semester_id)
);

CREATE TABLE Payment(
Payment_id INT PRIMARY KEY IDENTITY (1,1),
Student_id INT,
Fee_id INT,
Amount_paid DECIMAL(10,2),
Payment_date DATETIME,
Status VARCHAR(20) CHECK (Status IN ('Paid', 'Partial')),
FOREIGN KEY (Student_id) REFERENCES Student_University_Details(Student_id),
FOREIGN KEY (Fee_id) REFERENCES Fee(Fee_id)
);

CREATE TABLE Faculty_Salary(
Faculty_Salary_id INT PRIMARY KEY IDENTITY (1,1),
Faculty_id INT,
Salary_Month DATE,
Base_Salary DECIMAL(10,2),
Bonus DECIMAL(10,2) DEFAULT 0,
Deduction DECIMAL(10,2) DEFAULT 0,
Total_Salary AS (Base_Salary+Bonus-Deduction),
FOREIGN KEY (Faculty_id) REFERENCES Faculty_University_Details(Faculty_id)
);

CREATE TABLE Staff_Salary(
Staff_Salary_id INT PRIMARY KEY IDENTITY (1,1),
Staff_id INT,
Salary_Month DATE,
Base_Salary DECIMAL(10,2),
Bonus DECIMAL(10,2) DEFAULT 0,
Deduction DECIMAL(10,2) DEFAULT 0,
Total_Salary AS (Base_Salary+Bonus-Deduction),
FOREIGN KEY (Staff_id) REFERENCES Staff_University_Details(Staff_id)
);

---------------------------------------------------------------- ATTENDANCE RECORDS 

CREATE TABLE Student_Attendance(
Student_Attendance_id INT PRIMARY KEY IDENTITY (1,1),
Student_id INT,
Course_id INT,
Class_date DATE,
Attendance_Status VARCHAR(10) CHECK (Attendance_Status IN ('Present', 'Absent')),
FOREIGN KEY (Student_id) REFERENCES Student_University_Details(Student_id),
FOREIGN KEY (Course_id) REFERENCES Course(Course_id)
);

CREATE TABLE Faculty_Attendance(
Faculty_Attendance_id INT PRIMARY KEY IDENTITY (1,1),
Faculty_id INT,
Attendance_Date DATE,
Attendance_Status VARCHAR(10) CHECK (Attendance_Status IN ('Present', 'Absent', 'Late')),
FOREIGN KEY (Faculty_id) REFERENCES Faculty_University_Details(Faculty_id),
);

CREATE TABLE Staff_Attendance(
Staff_Attendance_id INT PRIMARY KEY IDENTITY (1,1),
Staff_id INT,
Attendance_Date DATE,
Attendance_Status VARCHAR(10) CHECK (Attendance_Status IN ('Present', 'Absent', 'Late')),
FOREIGN KEY (Staff_id) REFERENCES Staff_University_Details(Staff_id),
);

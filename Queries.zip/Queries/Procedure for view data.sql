
---------------------------------------------------------- STORED PROCEDURE TO VIEW DETAILS ---------------------------------------------------


--- **************************************************************************************
---                             STUDENT FULL RECORDS
---  *************************************************************************************

CREATE PROCEDURE ViewStudentFullProfile
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    -- Declare variables for Student Personal Details
    DECLARE 
        @StudentID INT,
        @FullName VARCHAR(201),
        @DOB DATE,
        @Gender VARCHAR(10),
        @Nationality VARCHAR(20),
        @CNIC VARCHAR(50),
        @Religion VARCHAR(20),
        @Permanent_Address VARCHAR(100),
        @Current_Address VARCHAR(100),
        @City VARCHAR(50),
        @Country VARCHAR(50),
        @Contact_Email VARCHAR(100),
        @Contact_Phone VARCHAR(15),
        @Emergency_Contact_Name VARCHAR(20),
        @Emergency_Contact_Relation VARCHAR(20),
        @Emergency_Contact VARCHAR(15);

    -- Declare variables for Guardian Information
    DECLARE 
        @GuardianFullName VARCHAR(201),
        @GuardianRelationship VARCHAR(20),
        @GuardianCNIC VARCHAR(50),
        @GuardianEmail VARCHAR(100),
        @GuardianPhone VARCHAR(15),
        @GuardianOccupation VARCHAR(50),
        @GuardianAddress VARCHAR(100);

    -- Declare variables for Admission Application
    DECLARE
        @ApplicationID INT,
        @Degree_Program_ID INT,
        @FSC INT,
        @FSC_Marks VARCHAR(20),
        @Is_Eligible VARCHAR(20),
        @Application_Date DATE,
        @Status VARCHAR(20),
        @Comments VARCHAR(MAX);

    -- Check if student exists by Full Name or CNIC or Email
    IF EXISTS (SELECT 1 FROM Student_Personal_DetailsWHERE Full_Name = @SearchKey OR CNIC = @SearchKey OR Contact_Email = @SearchKey)
    BEGIN
        -- Get Student Personal Details
        SELECT TOP 1
            @StudentID = Student_personal_id,
            @FullName = Full_Name,
            @DOB = Date_of_Birth,
            @Gender = Gender,
            @Nationality = Nationality,
            @CNIC = CNIC,
            @Religion = Religion,
            @Permanent_Address = Permanent_Address,
            @Current_Address = Current_Address,
            @City = City,
            @Country = Country,
            @Contact_Email = Contact_Email,
            @Contact_Phone = Contact_phone,
            @Emergency_Contact_Name = Emergency_contact_name,
            @Emergency_Contact_Relation = Emergency_contact_relation,
            @Emergency_Contact = Emergency_contact
        FROM Student_Personal_Details
        WHERE Full_Name = @SearchKey OR CNIC = @SearchKey OR Contact_Email = @SearchKey;

        -- Get Guardian Information
        SELECT TOP 1
            @GuardianFullName = Full_Name,
            @GuardianRelationship = Relationship,
            @GuardianCNIC = CNIC,
            @GuardianEmail = Contact_Email,
            @GuardianPhone = Contact_phone,
            @GuardianOccupation = Occupation,
            @GuardianAddress = Gaurdian_Address
        FROM Guardian_Information
        WHERE Student_personal_id = @StudentID;

        -- Get Admission Application Information
        SELECT TOP 1
            @ApplicationID = Application_id,
            @Degree_Program_ID = Degree_Program_id,
            @FSC = FSC,
            @FSC_Marks = FSC_Marks,
            @Is_Eligible = Is_eligible,
            @Application_Date = Application_date,
            @Status = Status,
            @Comments = Comments
        FROM Admission_Application
        WHERE Student_personal_id = @StudentID;

        -- Output Section - Professional formatting using PRINT and SELECT
        PRINT '====================== STUDENT PROFILE ======================';
        PRINT 'Full Name: ' + ISNULL(@FullName, 'N/A');
        PRINT 'Date of Birth: ' + ISNULL(CONVERT(VARCHAR(12), @DOB, 106), 'N/A');
        PRINT 'Gender: ' + ISNULL(@Gender, 'N/A');
        PRINT 'Nationality: ' + ISNULL(@Nationality, 'N/A');
        PRINT 'CNIC: ' + ISNULL(@CNIC, 'N/A');
        PRINT 'Religion: ' + ISNULL(@Religion, 'N/A');
        PRINT 'Permanent Address: ' + ISNULL(@Permanent_Address, 'N/A');
        PRINT 'Current Address: ' + ISNULL(@Current_Address, 'N/A');
        PRINT 'City: ' + ISNULL(@City, 'N/A');
        PRINT 'Country: ' + ISNULL(@Country, 'N/A');
        PRINT 'Email: ' + ISNULL(@Contact_Email, 'N/A');
        PRINT 'Phone: ' + ISNULL(@Contact_Phone, 'N/A');
        PRINT 'Emergency Contact Name: ' + ISNULL(@Emergency_Contact_Name, 'N/A');
        PRINT 'Emergency Contact Relation: ' + ISNULL(@Emergency_Contact_Relation, 'N/A');
        PRINT 'Emergency Contact Phone: ' + ISNULL(@Emergency_Contact, 'N/A');
        PRINT ' ';

        PRINT '====================== GUARDIAN INFORMATION ======================';
        PRINT 'Full Name: ' + ISNULL(@GuardianFullName, 'N/A');
        PRINT 'Relationship: ' + ISNULL(@GuardianRelationship, 'N/A');
        PRINT 'CNIC: ' + ISNULL(@GuardianCNIC, 'N/A');
        PRINT 'Email: ' + ISNULL(@GuardianEmail, 'N/A');
        PRINT 'Phone: ' + ISNULL(@GuardianPhone, 'N/A');
        PRINT 'Occupation: ' + ISNULL(@GuardianOccupation, 'N/A');
        PRINT 'Address: ' + ISNULL(@GuardianAddress, 'N/A');
        PRINT ' ';

        PRINT '====================== ADMISSION APPLICATION ======================';
        PRINT 'Application ID: ' + ISNULL(CAST(@ApplicationID AS VARCHAR(10)), 'N/A');
        PRINT 'Degree Program ID: ' + ISNULL(CAST(@Degree_Program_ID AS VARCHAR(10)), 'N/A');
        PRINT 'FSC: ' + ISNULL(CAST(@FSC AS VARCHAR(10)), 'N/A');
        PRINT 'FSC Marks: ' + ISNULL(@FSC_Marks, 'N/A');
        PRINT 'Eligibility: ' + ISNULL(@Is_Eligible, 'N/A');
        PRINT 'Application Date: ' + ISNULL(CONVERT(VARCHAR(12), @Application_Date, 106), 'N/A');
        PRINT 'Status: ' + ISNULL(@Status, 'N/A');
        PRINT 'Comments: ' + ISNULL(@Comments, 'N/A');
    END
    ELSE
    BEGIN
        PRINT 'No student found matching the search key: ' + @SearchKey;
    END
END;

-- ******************************************************************
EXEC ViewStudentFullProfile @SearchKey = 'Ali Khan';
-- or
EXEC ViewStudentFullProfile @SearchKey = '35202-1234567-8';
-- or
EXEC ViewStudentFullProfile @SearchKey = 'john.doe@gmail.com';
-- ******************************************************************

---------------------------------------------------------------------------------------------------------------------------


--- **************************************************************************************
---                         STUDENT ENROLLMENT FULL RECORDS
---  *************************************************************************************


CREATE PROCEDURE ViewEnrolledStudentProfile
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @StudentID INT,
        @FullName VARCHAR(200),
        @RollNumber VARCHAR(20),
        @EnrollmentDate DATE,
        @FeeAmount DECIMAL(10,2),
        @DueDate DATE,
        @AmountPaid DECIMAL(10,2),
        @PaymentDate DATETIME,
        @SemesterName VARCHAR(50),
        @SectionName CHAR(1),
        @UniversityEmail VARCHAR(100),
        @DegreeProgramName VARCHAR(50),
        @DegreeLevel VARCHAR(20),
        @Credits INT,
        @DurationYears VARCHAR(20);

    SELECT TOP 1
        @StudentID = sud.Student_id,
        @FullName = spd.Full_Name,
        @RollNumber = sud.Student_Roll_Number,
        @EnrollmentDate = en.Enrollment_date,
        @FeeAmount = f.Fee_amount,
        @DueDate = f.Due_date,
        @AmountPaid = p.Amount_paid,
        @PaymentDate = p.Payment_date,
        @SemesterName = sem.Semester_name,
        @SectionName = sec.Section_name,
        @UniversityEmail = sud.Student_University_Email,
        @DegreeProgramName = dp.Degree_Program_name,
        @DegreeLevel = dp.Degree_level,
        @Credits = dp.Credits,
        @DurationYears = dp.Duration_years
    FROM Student_University_Details sud
    INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
    INNER JOIN Enrolled_Students en ON sud.Student_id = en.Student_id
    INNER JOIN Semester sem ON en.Semester_id = sem.Semester_id
    INNER JOIN Section sec ON en.Section_id = sec.Section_id
    INNER JOIN Degree_Program dp ON sud.Degree_Program_id = dp.Degree_Program_id
    LEFT JOIN Fee f ON sud.Student_id = f.Student_id AND f.Semester_id = en.Semester_id
    LEFT JOIN Payment p ON sud.Student_id = p.Student_id AND p.Fee_id = f.Fee_id
    WHERE 
        spd.Full_Name = @SearchKey OR
        sud.Student_Roll_Number = @SearchKey OR
        sud.Student_University_Email = CONCAT(@SearchKey, '@uni.edu.pk');

    IF @StudentID IS NULL
    BEGIN
        PRINT 'No enrolled student found matching the search key: ' + @SearchKey;
        RETURN;
    END

    PRINT '================ STUDENT FULL PROFILE ================';
    PRINT 'Full Name          : ' + ISNULL(@FullName, 'N/A');
    PRINT 'Roll Number        : ' + ISNULL(@RollNumber, 'N/A');
    PRINT 'Enrollment Date    : ' + ISNULL(CONVERT(VARCHAR(12), @EnrollmentDate, 106), 'N/A');
    PRINT 'Fee Amount         : ' + ISNULL(CAST(@FeeAmount AS VARCHAR(20)), 'N/A');
    PRINT 'Due Date           : ' + ISNULL(CONVERT(VARCHAR(12), @DueDate, 106), 'N/A');
    PRINT 'Amount Paid        : ' + ISNULL(CAST(@AmountPaid AS VARCHAR(20)), 'N/A');
    PRINT 'Payment Date       : ' + ISNULL(CONVERT(VARCHAR(20), @PaymentDate, 113), 'N/A');
    PRINT 'Semester           : ' + ISNULL(@SemesterName, 'N/A');
    PRINT 'Section            : ' + ISNULL(@SectionName, 'N/A');
    PRINT 'University Email   : ' + ISNULL(@UniversityEmail, 'N/A');
    PRINT 'Degree Program     : ' + ISNULL(@DegreeProgramName, 'N/A');
    PRINT 'Degree Level       : ' + ISNULL(@DegreeLevel, 'N/A');
    PRINT 'Credits            : ' + ISNULL(CAST(@Credits AS VARCHAR(10)), 'N/A');
    PRINT 'Duration (Years)   : ' + ISNULL(@DurationYears, 'N/A');
    PRINT '======================================================';
END;


-- *****************************************************************

EXEC ViewEnrolledStudentProfile @SearchKey = 'Ahmad Khan';
-- Or by Roll Number
EXEC ViewEnrolledStudentProfile @SearchKey = '2023CS045';
-- Or by University Email username part only
EXEC ViewEnrolledStudentProfile @SearchKey = 'ahmad.khan';

-- *****************************************************************

-----------------------------------------------------------------------------------------------------------



--- **************************************************************************************
---                    ENROLLED  STUDENT WITH SCHOLARSHIP FULL RECORDS
---  *************************************************************************************

CREATE PROCEDURE ViewEnrolledStudentProfileScholarship
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @StudentID INT,
        @FullName VARCHAR(200),
        @RollNumber VARCHAR(20),
        @EnrollmentDate DATE,
        @FeeAmount DECIMAL(10,2),
        @DueDate DATE,
        @AmountPaid DECIMAL(10,2),
        @PaymentDate DATETIME,
        @SemesterName VARCHAR(50),
        @SectionName CHAR(1),
        @UniversityEmail VARCHAR(100),
        @DegreeProgramName VARCHAR(50),
        @DegreeLevel VARCHAR(20),
        @Credits INT,
        @DurationYears VARCHAR(20),

        -- Scholarship related variables
        @Scholarship_ApplicationDate DATE,
        @Scholarship_AwardDate DATE,
        @Scholarship_Status VARCHAR(20),
        @Scholarship_Description VARCHAR(100),
        @Scholarship_Amount DECIMAL(10,2),
        @Scholarship_Criteria VARCHAR(100);

    SELECT TOP 1
        @StudentID = sud.Student_id,
        @FullName = spd.Full_Name,
        @RollNumber = sud.Student_Roll_Number,
        @EnrollmentDate = en.Enrollment_date,
        @FeeAmount = f.Fee_amount,
        @DueDate = f.Due_date,
        @AmountPaid = p.Amount_paid,
        @PaymentDate = p.Payment_date,
        @SemesterName = sem.Semester_name,
        @SectionName = sec.Section_name,
        @UniversityEmail = sud.Student_University_Email,
        @DegreeProgramName = dp.Degree_Program_name,
        @DegreeLevel = dp.Degree_level,
        @Credits = dp.Credits,
        @DurationYears = dp.Duration_years,
        @Scholarship_ApplicationDate = ss.Application_date,
        @Scholarship_AwardDate = ss.Award_date,
        @Scholarship_Status = ss.Status,
        @Scholarship_Description = sch.Description,
        @Scholarship_Amount = sch.Amount,
        @Scholarship_Criteria = sch.Criteria
    FROM Student_University_Details sud
    INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
    INNER JOIN Enrolled_Students en ON sud.Student_id = en.Student_id
    INNER JOIN Semester sem ON en.Semester_id = sem.Semester_id
    INNER JOIN Section sec ON en.Section_id = sec.Section_id
    INNER JOIN Degree_Program dp ON sud.Degree_Program_id = dp.Degree_Program_id
    LEFT JOIN Fee f ON sud.Student_id = f.Student_id AND f.Semester_id = en.Semester_id
    LEFT JOIN Payment p ON sud.Student_id = p.Student_id AND p.Fee_id = f.Fee_id
    LEFT JOIN Student_Scholarship ss ON sud.Student_id = ss.Student_id
    LEFT JOIN Scholarship sch ON ss.Scholarship_id = sch.Scholarship_id
    WHERE 
        spd.Full_Name = @SearchKey OR
        sud.Student_Roll_Number = @SearchKey OR
        sud.Student_University_Email = CONCAT(@SearchKey, '@uni.edu.pk');

    IF @StudentID IS NULL
    BEGIN
        PRINT 'No enrolled student found matching the search key: ' + @SearchKey;
        RETURN;
    END

    PRINT '================ STUDENT FULL PROFILE ================';
    PRINT 'Full Name          : ' + ISNULL(@FullName, 'N/A');
    PRINT 'Roll Number        : ' + ISNULL(@RollNumber, 'N/A');
    PRINT 'Enrollment Date    : ' + ISNULL(CONVERT(VARCHAR(12), @EnrollmentDate, 106), 'N/A');
    PRINT 'Fee Amount         : ' + ISNULL(CAST(@FeeAmount AS VARCHAR(20)), 'N/A');
    PRINT 'Due Date           : ' + ISNULL(CONVERT(VARCHAR(12), @DueDate, 106), 'N/A');
    PRINT 'Amount Paid        : ' + ISNULL(CAST(@AmountPaid AS VARCHAR(20)), 'N/A');
    PRINT 'Payment Date       : ' + ISNULL(CONVERT(VARCHAR(20), @PaymentDate, 113), 'N/A');
    PRINT 'Semester           : ' + ISNULL(@SemesterName, 'N/A');
    PRINT 'Section            : ' + ISNULL(@SectionName, 'N/A');
    PRINT 'University Email   : ' + ISNULL(@UniversityEmail, 'N/A');
    PRINT 'Degree Program     : ' + ISNULL(@DegreeProgramName, 'N/A');
    PRINT 'Degree Level       : ' + ISNULL(@DegreeLevel, 'N/A');
    PRINT 'Credits            : ' + ISNULL(CAST(@Credits AS VARCHAR(10)), 'N/A');
    PRINT 'Duration (Years)   : ' + ISNULL(@DurationYears, 'N/A');
    
    PRINT '================ SCHOLARSHIP DETAILS ==================';
    PRINT 'Application Date   : ' + ISNULL(CONVERT(VARCHAR(12), @Scholarship_ApplicationDate, 106), 'N/A');
    PRINT 'Award Date         : ' + ISNULL(CONVERT(VARCHAR(12), @Scholarship_AwardDate, 106), 'N/A');
    PRINT 'Status             : ' + ISNULL(@Scholarship_Status, 'N/A');
    PRINT 'Description        : ' + ISNULL(@Scholarship_Description, 'N/A');
    PRINT 'Amount (%)         : ' + ISNULL(CAST(@Scholarship_Amount AS VARCHAR(20)), 'N/A');
    PRINT 'Criteria           : ' + ISNULL(@Scholarship_Criteria, 'N/A');
    PRINT '======================================================';
END;

-- *************************************************************************

EXEC ViewEnrolledStudentProfileScholarship @SearchKey = 'Ahmad Khan';


-- *************************************************************************

---------------------------------------------------------------------------------------------------------------------------------------------------


--- **************************************************************************************
---                    ENROLLED STUDENT ATTENDACE FULL RECORDS
---  *************************************************************************************


CREATE PROCEDURE ViewEnrolledStudentProfileAttendance
    @SearchKey VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @StudentID INT,
        @FullName VARCHAR(200),
        @RollNumber VARCHAR(20),
        @EnrollmentDate DATE,
        @SemesterName VARCHAR(50),
        @SectionName CHAR(1),
        @UniversityEmail VARCHAR(100),
        @DegreeProgramName VARCHAR(50),
        @DegreeLevel VARCHAR(20),
        @Credits INT,

        -- Attendance summary variables
        @TotalClasses INT,
        @PresentClasses INT,
        @AbsentClasses INT,
        @AttendancePercentage DECIMAL(5,2);

    -- Get main student info without scholarship & duration
    SELECT TOP 1
        @StudentID = sud.Student_id,
        @FullName = spd.Full_Name,
        @RollNumber = sud.Student_Roll_Number,
        @EnrollmentDate = en.Enrollment_date,
        @SemesterName = sem.Semester_name,
        @SectionName = sec.Section_name,
        @UniversityEmail = sud.Student_University_Email,
        @DegreeProgramName = dp.Degree_Program_name,
        @DegreeLevel = dp.Degree_level,
        @Credits = dp.Credits
    FROM Student_University_Details sud
    INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
    INNER JOIN Enrolled_Students en ON sud.Student_id = en.Student_id
    INNER JOIN Semester sem ON en.Semester_id = sem.Semester_id
    INNER JOIN Section sec ON en.Section_id = sec.Section_id
    INNER JOIN Degree_Program dp ON sud.Degree_Program_id = dp.Degree_Program_id
    WHERE 
        spd.Full_Name = @SearchKey OR
        sud.Student_Roll_Number = @SearchKey OR
        sud.Student_University_Email = CONCAT(@SearchKey, '@uni.edu.pk');

    IF @StudentID IS NULL
    BEGIN
        PRINT 'No enrolled student found matching the search key: ' + @SearchKey;
        RETURN;
    END

    -- Calculate attendance summary for last 7 days
    SELECT
        @TotalClasses = COUNT(*),
        @PresentClasses = SUM(CASE WHEN Attendance_Status = 'Present' THEN 1 ELSE 0 END),
        @AbsentClasses = SUM(CASE WHEN Attendance_Status = 'Absent' THEN 1 ELSE 0 END)
    FROM Student_Attendance
    WHERE Student_id = @StudentID
      AND Class_date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE));

    IF @TotalClasses > 0
        SET @AttendancePercentage = (@PresentClasses * 100.0) / @TotalClasses;
    ELSE
        SET @AttendancePercentage = 0;

    -- Print output
    PRINT '================ STUDENT FULL PROFILE ================';
    PRINT 'Full Name          : ' + ISNULL(@FullName, 'N/A');
    PRINT 'Roll Number        : ' + ISNULL(@RollNumber, 'N/A');
    PRINT 'Enrollment Date    : ' + ISNULL(CONVERT(VARCHAR(12), @EnrollmentDate, 106), 'N/A');
    PRINT 'Semester           : ' + ISNULL(@SemesterName, 'N/A');
    PRINT 'Section            : ' + ISNULL(@SectionName, 'N/A');
    PRINT 'University Email   : ' + ISNULL(@UniversityEmail, 'N/A');
    PRINT 'Degree Program     : ' + ISNULL(@DegreeProgramName, 'N/A');
    PRINT 'Degree Level       : ' + ISNULL(@DegreeLevel, 'N/A');
    PRINT 'Credits            : ' + ISNULL(CAST(@Credits AS VARCHAR(10)), 'N/A');

    PRINT '================ ATTENDANCE SUMMARY (Last 7 days) ======';
    PRINT 'Total Classes      : ' + CAST(@TotalClasses AS VARCHAR(10));
    PRINT 'Present            : ' + CAST(@PresentClasses AS VARCHAR(10));
    PRINT 'Absent             : ' + CAST(@AbsentClasses AS VARCHAR(10));
    PRINT 'Attendance %       : ' + CAST(ROUND(@AttendancePercentage, 2) AS VARCHAR(10)) + '%';
    PRINT '======================================================';
END;


-- ***********************************************************************

EXEC ViewEnrolledStudentProfileAttendance @SearchKey = 'Ahmad Khan';

-- ***********************************************************************



--- **************************************************************************************
---                    ENROLLED  STUDENT WITH RESULT FULL RECORDS
---  *************************************************************************************


CREATE PROCEDURE ViewStudentResultProfile
    @FullName VARCHAR(200),
    @SemesterID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @StudentID INT,
        @EnrollmentID INT,
        @UniversityEmail VARCHAR(100),
        @DegreeProgramName VARCHAR(50),
        @DegreeLevel VARCHAR(20),
        @SectionName CHAR(1),
        @Credits INT;

    -- Grade to GPA mapping
    DECLARE @GradePoints TABLE (
        Grade CHAR(2),
        Points DECIMAL(3,2)
    );

    INSERT INTO @GradePoints VALUES
    ('A', 4.0), ('A-', 3.7), ('B+', 3.3), ('B', 3.0), ('B-', 2.7),
    ('C+', 2.3), ('C', 2.0), ('C-', 1.7), ('D', 1.0), ('F', 0.0);

    -- Get student and enrollment info
    SELECT TOP 1
        @StudentID = sud.Student_id,
        @UniversityEmail = sud.Student_University_Email,
        @DegreeProgramName = dp.Degree_Program_name,
        @DegreeLevel = dp.Degree_level,
        @SectionName = sec.Section_name,
        @Credits = dp.Credits,
        @EnrollmentID = en.Enrollment_id
    FROM Student_University_Details sud
    INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
    INNER JOIN Enrolled_Students en ON sud.Student_id = en.Student_id
    INNER JOIN Semester sem ON en.Semester_id = sem.Semester_id
    INNER JOIN Section sec ON en.Section_id = sec.Section_id
    INNER JOIN Degree_Program dp ON sud.Degree_Program_id = dp.Degree_Program_id
    WHERE spd.Full_Name = @FullName AND sem.Semester_id = @SemesterID;

    IF @StudentID IS NULL
    BEGIN
        PRINT 'No matching student found for given name and semester ID.';
        RETURN;
    END

    PRINT '================ STUDENT RESULT PROFILE ================';
    PRINT 'Full Name          : ' + @FullName;
    PRINT 'Email              : ' + ISNULL(@UniversityEmail, 'N/A');
    PRINT 'Degree Program     : ' + ISNULL(@DegreeProgramName, 'N/A');
    PRINT 'Degree Level       : ' + ISNULL(@DegreeLevel, 'N/A');
    PRINT 'Section            : ' + ISNULL(@SectionName, 'N/A');
    PRINT 'Semester ID        : ' + CAST(@SemesterID AS VARCHAR);

    PRINT '';
    PRINT '----------------- COURSE RESULTS -----------------';

    -- Temporary table to hold results
    CREATE TABLE #TempResults (
        Course_title VARCHAR(100),
        Marks FLOAT,
        Grade CHAR(2),
        Credits INT,
        Points DECIMAL(3,2)
    );

    INSERT INTO #TempResults (Course_title, Marks, Grade, Credits, Points)
    SELECT 
        c.Course_title,
        cr.Marks_obtained,
        cr.Grade,
        c.Credits,
        gp.Points
    FROM Course_results cr
    INNER JOIN Course c ON cr.Course_id = c.Course_id
    INNER JOIN @GradePoints gp ON gp.Grade = cr.Grade
    WHERE cr.Enrollment_id = @EnrollmentID;

    -- Print each course result
    DECLARE @Course_title VARCHAR(100), @Marks FLOAT, @Grade CHAR(2), @Credit INT, @Point DECIMAL(3,2);
    DECLARE course_cursor CURSOR FOR
        SELECT Course_title, Marks, Grade, Credits, Points FROM #TempResults;

    OPEN course_cursor;
    FETCH NEXT FROM course_cursor INTO @Course_title, @Marks, @Grade, @Credit, @Point;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT 'Course : ' + @Course_title + 
              ' | Marks : ' + CAST(@Marks AS VARCHAR) + 
              ' | Grade : ' + @Grade + 
              ' | Credit : ' + CAST(@Credit AS VARCHAR) +
              ' | GPA : ' + CAST(@Point AS VARCHAR);
        FETCH NEXT FROM course_cursor INTO @Course_title, @Marks, @Grade, @Credit, @Point;
    END

    CLOSE course_cursor;
    DEALLOCATE course_cursor;

    -- SGPA Calculation
    DECLARE @TotalCredits INT, @TotalPoints DECIMAL(5,2), @SGPA DECIMAL(5,2);

    SELECT 
        @TotalCredits = SUM(Credits),
        @TotalPoints = SUM(Credits * Points)
    FROM #TempResults;

    IF @TotalCredits > 0
        SET @SGPA = @TotalPoints / @TotalCredits;
    ELSE
        SET @SGPA = 0;

    PRINT '-------------------------------------------------';
    PRINT 'SGPA (Semester GPA) : ' + CAST(@SGPA AS VARCHAR);
    PRINT '=================================================';

    DROP TABLE #TempResults;
END


-- **************************************************************************

EXEC ViewStudentResultProfile @FullName = 'Ahmad Khan', @SemesterID = 1;

-- **************************************************************************


-------------------------------------------------------------------------------------------


--- **************************************************************************************
---                              FACULTY  FULL RECORDS
---  *************************************************************************************


CREATE PROCEDURE ViewFacultyFullProfile
    @FullName VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @FacultyID INT,
        @Full_Name VARCHAR(200),
        @DateOfBirth DATE,
        @Gender VARCHAR(10),
        @Nationality VARCHAR(20),
        @CNIC VARCHAR(50),
        @Religion VARCHAR(20),
        @Address VARCHAR(100),
        @City VARCHAR(50),
        @Country VARCHAR(50),
        @Email VARCHAR(50),
        @Phone VARCHAR(20),
        @HireDate DATE,
        @DepartmentID INT,
        @Designation VARCHAR(50),
        @Status VARCHAR(20),

        -- Salary
        @BaseSalary DECIMAL(10,2),
        @Bonus DECIMAL(10,2),
        @Deduction DECIMAL(10,2),
        @TotalSalary DECIMAL(10,2),

        -- Attendance
        @TotalDays INT,
        @PresentDays INT,
        @AbsentDays INT,
        @LateDays INT;

    -- Fetch main profile data
    SELECT TOP 1
        @FacultyID = fud.Faculty_id,
        @Full_Name = fpd.First_name + ' ' + fpd.Last_name,
        @DateOfBirth = fpd.Date_of_Birth,
        @Gender = fpd.Gender,
        @Nationality = fpd.Nationality,
        @CNIC = fpd.CNIC,
        @Religion = fpd.Religion,
        @Address = fpd.Address,
        @City = fpd.City,
        @Country = fpd.Country,
        @Email = CONCAT(fpd.Faculty_Personal_email, '@gmail.com'),
        @Phone = CONCAT('+92', fpd.Faculty_Personal_phone),
        @HireDate = fud.Hire_date,
        @DepartmentID = fud.Department_id,
        @Designation = fud.Designation,
        @Status = fud.Status
    FROM Faculty_Personal_Details fpd
    INNER JOIN Faculty_University_Details fud ON fpd.Faculty_personal_id = fud.Faculty_personal_id
    WHERE fpd.First_name + ' ' + fpd.Last_name = @FullName;

    IF @FacultyID IS NULL
    BEGIN
        PRINT 'No faculty member found with name: ' + @FullName;
        RETURN;
    END

    -- Latest Salary (most recent month)
    SELECT TOP 1 
        @BaseSalary = Base_Salary,
        @Bonus = Bonus,
        @Deduction = Deduction,
        @TotalSalary = Base_Salary + Bonus - Deduction
    FROM Faculty_Salary
    WHERE Faculty_id = @FacultyID
    ORDER BY Salary_Month DESC;

    -- Attendance Summary (last 7 days)
    SELECT
        @TotalDays = COUNT(*),
        @PresentDays = SUM(CASE WHEN Attendance_Status = 'Present' THEN 1 ELSE 0 END),
        @AbsentDays = SUM(CASE WHEN Attendance_Status = 'Absent' THEN 1 ELSE 0 END),
        @LateDays = SUM(CASE WHEN Attendance_Status = 'Late' THEN 1 ELSE 0 END)
    FROM Faculty_Attendance
    WHERE Faculty_id = @FacultyID
      AND Attendance_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE));

    -- Output
    PRINT '================ FACULTY FULL PROFILE ================';
    PRINT 'Full Name          : ' + ISNULL(@Full_Name, 'N/A');
    PRINT 'Date of Birth      : ' + ISNULL(CONVERT(VARCHAR, @DateOfBirth, 106), 'N/A');
    PRINT 'Gender             : ' + ISNULL(@Gender, 'N/A');
    PRINT 'Nationality        : ' + ISNULL(@Nationality, 'N/A');
    PRINT 'CNIC               : ' + ISNULL(@CNIC, 'N/A');
    PRINT 'Religion           : ' + ISNULL(@Religion, 'N/A');
    PRINT 'Address            : ' + ISNULL(@Address, 'N/A');
    PRINT 'City               : ' + ISNULL(@City, 'N/A');
    PRINT 'Country            : ' + ISNULL(@Country, 'N/A');
    PRINT 'Email              : ' + ISNULL(@Email, 'N/A');
    PRINT 'Phone              : ' + ISNULL(@Phone, 'N/A');
    PRINT 'Hire Date          : ' + ISNULL(CONVERT(VARCHAR, @HireDate, 106), 'N/A');
    PRINT 'Department ID      : ' + CAST(@DepartmentID AS VARCHAR);
    PRINT 'Designation        : ' + ISNULL(@Designation, 'N/A');
    PRINT 'Status             : ' + ISNULL(@Status, 'N/A');

    PRINT '';
    PRINT '------------------ SALARY SUMMARY ------------------';
    PRINT 'Base Salary        : ' + ISNULL(CAST(@BaseSalary AS VARCHAR), 'N/A');
    PRINT 'Bonus              : ' + ISNULL(CAST(@Bonus AS VARCHAR), 'N/A');
    PRINT 'Deduction          : ' + ISNULL(CAST(@Deduction AS VARCHAR), 'N/A');
    PRINT 'Total Salary       : ' + ISNULL(CAST(@TotalSalary AS VARCHAR), 'N/A');

    PRINT '';
    PRINT '--------------- ATTENDANCE (Last 7 Days) ---------------';
    PRINT 'Total Days         : ' + CAST(ISNULL(@TotalDays, 0) AS VARCHAR);
    PRINT 'Present            : ' + CAST(ISNULL(@PresentDays, 0) AS VARCHAR);
    PRINT 'Absent             : ' + CAST(ISNULL(@AbsentDays, 0) AS VARCHAR);
    PRINT 'Late               : ' + CAST(ISNULL(@LateDays, 0) AS VARCHAR);
END;



-- ********************************************************************

EXEC ViewFacultyFullProfile @FullName = 'Ali Khan';

-- ********************************************************************


------------------------------------------------------------------------------



--- **************************************************************************************
---                              STAFF  FULL RECORDS
---  *************************************************************************************


CREATE PROCEDURE ViewStaffFullProfile
    @FullName VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @StaffID INT,
        @Full_Name VARCHAR(200),
        @DateOfBirth DATE,
        @Gender VARCHAR(10),
        @Nationality VARCHAR(20),
        @CNIC VARCHAR(50),
        @Religion VARCHAR(20),
        @Address VARCHAR(100),
        @City VARCHAR(50),
        @Country VARCHAR(50),
        @Email VARCHAR(100),
        @Phone VARCHAR(20),
        @HireDate DATE,
        @Designation VARCHAR(50),
        @StaffType VARCHAR(20),
        @Status VARCHAR(20),

        -- Salary
        @BaseSalary DECIMAL(10,2),
        @Bonus DECIMAL(10,2),
        @Deduction DECIMAL(10,2),
        @TotalSalary DECIMAL(10,2),

        -- Attendance
        @TotalDays INT,
        @PresentDays INT,
        @AbsentDays INT,
        @LateDays INT;

    -- Fetch main profile data
    SELECT TOP 1
        @StaffID = sud.Staff_id,
        @Full_Name = spd.First_name + ' ' + spd.Last_name,
        @DateOfBirth = spd.Date_of_Birth,
        @Gender = spd.Gender,
        @Nationality = spd.Nationality,
        @CNIC = spd.CNIC,
        @Religion = spd.Religion,
        @Address = spd.Address,
        @City = spd.City,
        @Country = spd.Country,
        @Email = CONCAT(spd.Staff_Personal_email, '@gmail.com'),
        @Phone = CONCAT('+92', spd.Staff_Personal_phone),
        @HireDate = sud.Hire_date,
        @Designation = sud.Designation,
        @StaffType = sud.Staff_Type,
        @Status = sud.Status
    FROM Staff_Personal_Details spd
    INNER JOIN Staff_University_Details sud ON spd.Staff_personal_id = sud.Staff_Personal_id
    WHERE spd.First_name + ' ' + spd.Last_name = @FullName;

    IF @StaffID IS NULL
    BEGIN
        PRINT 'No staff member found with name: ' + @FullName;
        RETURN;
    END

    -- Latest Salary (most recent month)
    SELECT TOP 1 
        @BaseSalary = Base_Salary,
        @Bonus = Bonus,
        @Deduction = Deduction,
        @TotalSalary = Base_Salary + Bonus - Deduction
    FROM Staff_Salary
    WHERE Staff_id = @StaffID
    ORDER BY Salary_Month DESC;

    -- Attendance Summary (last 7 days)
    SELECT
        @TotalDays = COUNT(*),
        @PresentDays = SUM(CASE WHEN Attendance_Status = 'Present' THEN 1 ELSE 0 END),
        @AbsentDays = SUM(CASE WHEN Attendance_Status = 'Absent' THEN 1 ELSE 0 END),
        @LateDays = SUM(CASE WHEN Attendance_Status = 'Late' THEN 1 ELSE 0 END)
    FROM Staff_Attendance
    WHERE Staff_id = @StaffID
      AND Attendance_Date >= DATEADD(DAY, -7, CAST(GETDATE() AS DATE));

    -- Print full profile
    PRINT '================ STAFF FULL PROFILE ================';

    PRINT 'Full Name          : ' + @Full_Name;
    PRINT 'Date of Birth      : ' + ISNULL(CONVERT(VARCHAR, @DateOfBirth, 106), 'N/A');
    PRINT 'Gender             : ' + ISNULL(@Gender, 'N/A');
    PRINT 'CNIC               : ' + ISNULL(@CNIC, 'N/A');
    PRINT 'Nationality        : ' + ISNULL(@Nationality, 'N/A');
    PRINT 'Religion           : ' + ISNULL(@Religion, 'N/A');
    PRINT 'Address            : ' + ISNULL(@Address, 'N/A');
    PRINT 'City               : ' + ISNULL(@City, 'N/A');
    PRINT 'Country            : ' + ISNULL(@Country, 'N/A');
    PRINT 'Email              : ' + ISNULL(@Email, 'N/A');
    PRINT 'Phone              : ' + ISNULL(@Phone, 'N/A');
    PRINT 'Hire Date          : ' + ISNULL(CONVERT(VARCHAR, @HireDate, 106), 'N/A');
    PRINT 'Designation        : ' + ISNULL(@Designation, 'N/A');
    PRINT 'Staff Type         : ' + ISNULL(@StaffType, 'N/A');
    PRINT 'Status             : ' + ISNULL(@Status, 'N/A');

    PRINT '';
    PRINT '---------------- SALARY SUMMARY (Latest Month) ----------------';
    PRINT 'Base Salary        : ' + ISNULL(CAST(@BaseSalary AS VARCHAR), 'N/A');
    PRINT 'Bonus              : ' + ISNULL(CAST(@Bonus AS VARCHAR), 'N/A');
    PRINT 'Deduction          : ' + ISNULL(CAST(@Deduction AS VARCHAR), 'N/A');
    PRINT 'Total Salary       : ' + ISNULL(CAST(@TotalSalary AS VARCHAR), 'N/A');

    PRINT '';
    PRINT '---------------- ATTENDANCE SUMMARY (Last 7 Days) ----------------';
    PRINT 'Total Days         : ' + ISNULL(CAST(@TotalDays AS VARCHAR), '0');
    PRINT 'Present Days       : ' + ISNULL(CAST(@PresentDays AS VARCHAR), '0');
    PRINT 'Absent Days        : ' + ISNULL(CAST(@AbsentDays AS VARCHAR), '0');
    PRINT 'Late Days          : ' + ISNULL(CAST(@LateDays AS VARCHAR), '0');
END;


-- ********************************************************

EXEC ViewStaffFullProfile @FullName = 'Ali Raza';

-- ********************************************************


---------------------------------------------------------------------------------


--- **************************************************************************************
---                              ACADEMIC  FULL DETAILS
---  *************************************************************************************


CREATE PROCEDURE ViewAcademicDetails
    @SearchValue VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    -- Case 1: Search by Department
    IF EXISTS (SELECT 1 FROM Departments WHERE Department_name = @SearchValue)
    BEGIN
        DECLARE @DeptID INT;
        SELECT @DeptID = Department_id FROM Departments WHERE Department_name = @SearchValue;

        PRINT 'Department Name: ' + @SearchValue;
        PRINT '';
        PRINT 'Degree Programs Related to Department:';

        DECLARE dp_cursor CURSOR FOR
        SELECT Degree_Program_name, Degree_Program_id FROM Degree_Program WHERE Department_id = @DeptID;

        DECLARE @DegName VARCHAR(100), @DegID INT, @Index INT = 1;
        OPEN dp_cursor;
        FETCH NEXT FROM dp_cursor INTO @DegName, @DegID;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            PRINT CAST(@Index AS VARCHAR) + '. ' + @DegName;
            SET @Index += 1;

            PRINT '   Courses under "' + @DegName + '":';

            DECLARE c_cursor CURSOR FOR
            SELECT Course_title FROM Course WHERE Degree_Program_id = @DegID;
            
            DECLARE @CName VARCHAR(100), @CIndex INT = 1;
            OPEN c_cursor;
            FETCH NEXT FROM c_cursor INTO @CName;
            WHILE @@FETCH_STATUS = 0
            BEGIN
                PRINT '     ' + CAST(@CIndex AS VARCHAR) + ') ' + @CName;
                SET @CIndex += 1;
                FETCH NEXT FROM c_cursor INTO @CName;
            END
            CLOSE c_cursor;
            DEALLOCATE c_cursor;

            FETCH NEXT FROM dp_cursor INTO @DegName, @DegID;
        END
        CLOSE dp_cursor;
        DEALLOCATE dp_cursor;
    END

    -- Case 2: Search by Degree Program
    ELSE IF EXISTS (SELECT 1 FROM Degree_Program WHERE Degree_Program_name = @SearchValue)
    BEGIN
        DECLARE @DegreeID INT, @DeptName VARCHAR(100), @DeptID2 INT;
        SELECT @DegreeID = Degree_Program_id, @DeptID2 = Department_id FROM Degree_Program WHERE Degree_Program_name = @SearchValue;
        SELECT @DeptName = Department_name FROM Departments WHERE Department_id = @DeptID2;

        PRINT 'Degree Program Name: ' + @SearchValue;
        PRINT 'Belongs to Department: ' + @DeptName;
        PRINT '';
        PRINT 'Courses of Degree Program "' + @SearchValue + '":';

        DECLARE course_cursor CURSOR FOR
        SELECT Course_title FROM Course WHERE Degree_Program_id = @DegreeID;

        DECLARE @Title VARCHAR(100), @Counter INT = 1;
        OPEN course_cursor;
        FETCH NEXT FROM course_cursor INTO @Title;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            PRINT CAST(@Counter AS VARCHAR) + '. ' + @Title;
            SET @Counter += 1;
            FETCH NEXT FROM course_cursor INTO @Title;
        END
        CLOSE course_cursor;
        DEALLOCATE course_cursor;
    END

    -- Case 3: Search by Course Title
    ELSE IF EXISTS (SELECT 1 FROM Course WHERE Course_title = @SearchValue)
    BEGIN
        DECLARE @DegID3 INT, @DeptID3 INT, @DegName3 VARCHAR(100), @DeptName3 VARCHAR(100);
        SELECT @DegID3 = Degree_Program_id, @DeptID3 = Department_id FROM Course WHERE Course_title = @SearchValue;
        SELECT @DegName3 = Degree_Program_name FROM Degree_Program WHERE Degree_Program_id = @DegID3;
        SELECT @DeptName3 = Department_name FROM Departments WHERE Department_id = @DeptID3;

        PRINT 'Course Title: ' + @SearchValue;
        PRINT 'Belongs to Degree Program: ' + @DegName3;
        PRINT 'Belongs to Department: ' + @DeptName3;
    END

    ELSE
    BEGIN
        PRINT 'No matching Department, Degree Program, or Course found for "' + @SearchValue + '"';
    END
END;


-- ************************************************************************************************

EXEC ViewAcademicDetails @SearchValue = 'Bachelor of Computer Science'; -- Degree Program

EXEC ViewAcademicDetails @SearchValue = 'Computer Science'; -- Department

EXEC ViewAcademicDetails @SearchValue = 'Introduction to Programming'; -- Course

-- ************************************************************************************************


-------------------------------------------------------------------------------------


--- **************************************************************************************
---                         STUDENT WHO BORROW BOOK FULL RECORDS
---  *************************************************************************************



CREATE PROCEDURE ViewStudentBookDetails_Print
    @SearchTerm VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @FullName VARCHAR(200), 
        @RollNo VARCHAR(50), 
        @Phone VARCHAR(20), 
        @Email VARCHAR(100),
        @Department VARCHAR(100), 
        @Section VARCHAR(10), 
        @Semester VARCHAR(50),
        @BookTitle VARCHAR(100), 
        @Author VARCHAR(100), 
        @Edition VARCHAR(50), 
        @Publisher VARCHAR(100),
        @Category VARCHAR(100),
        @BorrowedDate DATE, 
        @ReturnDate DATE

    DECLARE cur CURSOR FOR
    SELECT 
        spd.Full_Name,
        sud.Student_Roll_Number,
        spd.Contact_phone,
        sud.Student_University_Email,
        d.Department_name,
        s.Section_name,
        sem.Semester_name,
        lb.Title,
        lb.Author,
        lb.Edition,
        lb.Publisher,
        bc.Category_name,
        bb.Borrowed_date,
        br.Returned_date
    FROM Book_Borrow bb
    INNER JOIN Library_Book lb ON bb.Book_id = lb.Book_id
    INNER JOIN Book_Category bc ON lb.Category_id = bc.Category_id
    INNER JOIN Student_University_Details sud ON bb.Student_id = sud.Student_id
    INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
    INNER JOIN Departments d ON sud.Department_id = d.Department_id
    INNER JOIN Section s ON sud.Section_id = s.Section_id
    INNER JOIN Semester sem ON s.Semester_id = sem.Semester_id
    INNER JOIN Book_Returned br ON bb.Borrow_id = br.Borrow_id
    WHERE spd.Full_Name LIKE '%' + @SearchTerm + '%'
       OR lb.Title LIKE '%' + @SearchTerm + '%';

    OPEN cur
    FETCH NEXT FROM cur INTO 
        @FullName, @RollNo, @Phone, @Email, @Department, @Section, @Semester,
        @BookTitle, @Author, @Edition, @Publisher, @Category, @BorrowedDate, @ReturnDate

    WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT '--------------------------------------------------'
        PRINT 'Student Name       : ' + @FullName
        PRINT 'Roll No            : ' + @RollNo
        PRINT 'Phone Number       : ' + @Phone
        PRINT 'University Email   : ' + @Email
        PRINT 'Department         : ' + @Department
        PRINT 'Section            : ' + @Section
        PRINT 'Semester           : ' + @Semester
        PRINT ''
        PRINT 'Book Title         : ' + @BookTitle
        PRINT 'Author             : ' + @Author
        PRINT 'Edition            : ' + @Edition
        PRINT 'Publisher          : ' + @Publisher
        PRINT 'Category           : ' + @Category
        PRINT ''
        PRINT 'Borrowed Date      : ' + CONVERT(VARCHAR, @BorrowedDate, 23)
        PRINT 'Return Date        : ' + CONVERT(VARCHAR, @ReturnDate, 23)
        PRINT '--------------------------------------------------'

        FETCH NEXT FROM cur INTO 
            @FullName, @RollNo, @Phone, @Email, @Department, @Section, @Semester,
            @BookTitle, @Author, @Edition, @Publisher, @Category, @BorrowedDate, @ReturnDate
    END

    CLOSE cur
    DEALLOCATE cur
END

-- *********************************************************************

EXEC ViewStudentBookDetails_Print @SearchTerm = 'Ahmad Khan';
-- or
EXEC ViewStudentBookDetails_Print @SearchTerm = 'Introduction to AI';

-- *********************************************************************


--------------------------------------------------------------------------------


--- **************************************************************************************
---                              BOOK DETAILS
---  *************************************************************************************


CREATE PROCEDURE ViewBookOrCategoryDetails_Print
    @SearchTerm VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @BookTitle VARCHAR(100),
        @Author VARCHAR(100),
        @Publisher VARCHAR(100),
        @PublicationYear INT,
        @Edition VARCHAR(50),
        @CategoryName VARCHAR(100),
        @TotalCopies INT,
        @AvailableCopies INT,
        @Status VARCHAR(20)

    -- Cursor for Category Match
    IF EXISTS (
        SELECT 1 FROM Book_Category WHERE Category_name LIKE '%' + @SearchTerm + '%'
    )
    BEGIN
        DECLARE cur_category CURSOR FOR
        SELECT 
            lb.Title,
            lb.Author
        FROM Library_Book lb
        INNER JOIN Book_Category bc ON lb.Category_id = bc.Category_id
        WHERE bc.Category_name LIKE '%' + @SearchTerm + '%'

        OPEN cur_category
        FETCH NEXT FROM cur_category INTO @BookTitle, @Author

        WHILE @@FETCH_STATUS = 0
        BEGIN
            PRINT '-----------------------------------------'
            PRINT 'Category Match Found'
            PRINT 'Book Title     : ' + @BookTitle
            PRINT 'Author         : ' + @Author
            PRINT '-----------------------------------------'
            FETCH NEXT FROM cur_category INTO @BookTitle, @Author
        END

        CLOSE cur_category
        DEALLOCATE cur_category
    END

    -- Cursor for Book Match
    ELSE IF EXISTS (
        SELECT 1 FROM Library_Book WHERE Title LIKE '%' + @SearchTerm + '%'
    )
    BEGIN
        DECLARE cur_book CURSOR FOR
        SELECT 
            lb.Title,
            lb.Author,
            lb.Publisher,
            lb.Publication_Year,
            lb.Edition,
            bc.Category_name,
            lb.Total_Copies,
            lb.Available_Copies,
            lb.Status
        FROM Library_Book lb
        INNER JOIN Book_Category bc ON lb.Category_id = bc.Category_id
        WHERE lb.Title LIKE '%' + @SearchTerm + '%'

        OPEN cur_book
        FETCH NEXT FROM cur_book INTO 
            @BookTitle, @Author, @Publisher, @PublicationYear, @Edition, 
            @CategoryName, @TotalCopies, @AvailableCopies, @Status

        WHILE @@FETCH_STATUS = 0
        BEGIN
            PRINT '-----------------------------------------'
            PRINT 'Book Match Found'
            PRINT 'Title            : ' + @BookTitle
            PRINT 'Author           : ' + @Author
            PRINT 'Publisher        : ' + @Publisher
            PRINT 'Publication Year : ' + CAST(@PublicationYear AS VARCHAR)
            PRINT 'Edition          : ' + @Edition
            PRINT 'Category         : ' + @CategoryName
            PRINT 'Total Copies     : ' + CAST(@TotalCopies AS VARCHAR)
            PRINT 'Available Copies : ' + CAST(@AvailableCopies AS VARCHAR)
            PRINT 'Status           : ' + @Status
            PRINT '-----------------------------------------'
            FETCH NEXT FROM cur_book INTO 
                @BookTitle, @Author, @Publisher, @PublicationYear, @Edition, 
                @CategoryName, @TotalCopies, @AvailableCopies, @Status
        END

        CLOSE cur_book
        DEALLOCATE cur_book
    END
    ELSE
    BEGIN
        PRINT 'No matching category or book found for the search term: ' + @SearchTerm
    END
END


-- *************************************************************************************

EXEC ViewBookOrCategoryDetails_Print 'Science Fiction'; -- if category
EXEC ViewBookOrCategoryDetails_Print 'Introduction to Algorithms'; -- if book title

-- *************************************************************************************

--------------------------------------------------------------------------------------------------


--- **************************************************************************************
---                              EXAMS DETAILS
---  *************************************************************************************


CREATE PROCEDURE ViewExamDetails_Print
    @SearchTerm VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @ExamType VARCHAR(10),
        @CourseTitle VARCHAR(50),
        @CourseCode VARCHAR(10),
        @SectionName CHAR(1),
        @SemesterName VARCHAR(20),
        @AcademicYear INT,
        @ExamDate DATE,
        @StartTime VARCHAR(20),
        @EndTime VARCHAR(20),
        @RoomNumber INT,
        @BuildingName VARCHAR(50),
        @InvigilatorName VARCHAR(200),
        @TotalMarks INT,
        @PassingMarks INT,
        @ExamStatus VARCHAR(10)

    DECLARE cur CURSOR FOR
    SELECT 
        e.Exam_type,
        c.Course_title,
        c.Course_code,
        s.Section_name,
        sem.Semester_name,
        sem.Academic_year,
        e.Exam_date,
        CONVERT(VARCHAR, e.Start_time, 108),
        CONVERT(VARCHAR, e.End_time, 108),
        cr.Room_number,
        b.Building_name,
        fpd.First_name + ' ' + fpd.Last_name,
        e.Total_marks,
        e.Passing_marks,
        e.Status
    FROM Exam e
    INNER JOIN Course c ON e.Course_id = c.Course_id
    INNER JOIN Section s ON e.Section_id = s.Section_id
    INNER JOIN Semester sem ON e.Semester_id = sem.Semester_id
    INNER JOIN Classroom cr ON e.Classroom_id = cr.Classroom_id
    INNER JOIN Building b ON cr.Building_id = b.Building_id
    INNER JOIN Faculty_University_Details fud ON e.Invigilator_id = fud.Faculty_id
    INNER JOIN Faculty_Personal_Details fpd ON fud.Faculty_personal_id = fpd.Faculty_personal_id
    WHERE c.Course_title LIKE '%' + @SearchTerm + '%'
       OR s.Section_name LIKE '%' + @SearchTerm + '%'
       OR e.Exam_type LIKE '%' + @SearchTerm + '%';

    OPEN cur
    FETCH NEXT FROM cur INTO 
        @ExamType, @CourseTitle, @CourseCode, @SectionName, @SemesterName, @AcademicYear,
        @ExamDate, @StartTime, @EndTime, @RoomNumber, @BuildingName, @InvigilatorName,
        @TotalMarks, @PassingMarks, @ExamStatus

    WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT '--------------------------------------------------'
        PRINT 'Exam Type        : ' + @ExamType
        PRINT 'Course           : ' + @CourseTitle + ' (' + @CourseCode + ')'
        PRINT 'Section          : ' + @SectionName
        PRINT 'Semester         : ' + @SemesterName + ' - ' + CAST(@AcademicYear AS VARCHAR)
        PRINT 'Exam Date        : ' + CONVERT(VARCHAR, @ExamDate, 23)
        PRINT 'Start Time       : ' + @StartTime
        PRINT 'End Time         : ' + @EndTime
        PRINT 'Classroom        : Room ' + CAST(@RoomNumber AS VARCHAR) + ', ' + @BuildingName
        PRINT 'Invigilator      : ' + @InvigilatorName
        PRINT 'Total Marks      : ' + CAST(@TotalMarks AS VARCHAR)
        PRINT 'Passing Marks    : ' + CAST(@PassingMarks AS VARCHAR)
        PRINT 'Status           : ' + @ExamStatus
        PRINT '--------------------------------------------------'
        
        FETCH NEXT FROM cur INTO 
            @ExamType, @CourseTitle, @CourseCode, @SectionName, @SemesterName, @AcademicYear,
            @ExamDate, @StartTime, @EndTime, @RoomNumber, @BuildingName, @InvigilatorName,
            @TotalMarks, @PassingMarks, @ExamStatus
    END

    CLOSE cur
    DEALLOCATE cur
END


-- ****************************************************************

EXEC ViewExamDetails_Print @SearchTerm = 'Final';
EXEC ViewExamDetails_Print @SearchTerm = 'OOP';
EXEC ViewExamDetails_Print @SearchTerm = 'A';

-- ****************************************************************

------------------------------------------------------------------------




CREATE PROCEDURE ViewTimetableDetails_Print
    @DegreeProgramName VARCHAR(100),
    @SemesterName VARCHAR(50),
    @SectionName CHAR
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE 
        @DayOfWeek VARCHAR(10),
        @StartTime VARCHAR(10),
        @EndTime VARCHAR(10),
        @RoomNumber INT,
        @BuildingName VARCHAR(50),
        @DegreeProgram VARCHAR(100),
        @Semester VARCHAR(50),
        @Section CHAR(1)

    DECLARE cur CURSOR FOR
    SELECT 
        ts.Day_of_week,
        CONVERT(VARCHAR, ts.Start_time, 108),
        CONVERT(VARCHAR, ts.End_time, 108),
        c.Room_number,
        b.Building_name,
        dp.Degree_Program_name,
        sem.Semester_name,
        s.Section_name
    FROM Timetable t
    INNER JOIN Section s ON t.Section_id = s.Section_id
    INNER JOIN Semester sem ON t.Semester_id = sem.Semester_id
    INNER JOIN Degree_Program dp ON t.Degree_Program_id = dp.Degree_Program_id
    INNER JOIN Time_slots ts ON t.Time_slot_id = ts.Time_slot_id
    INNER JOIN Classroom c ON t.Classroom_id = c.Classroom_id
    INNER JOIN Building b ON c.Building_id = b.Building_id
    WHERE 
        dp.Degree_Program_name = @DegreeProgramName AND
        sem.Semester_name = @SemesterName AND
        s.Section_name = @SectionName
    ORDER BY 
        CASE 
            WHEN ts.Day_of_week = 'Monday' THEN 1
            WHEN ts.Day_of_week = 'Tuesday' THEN 2
            WHEN ts.Day_of_week = 'Wednesday' THEN 3
            WHEN ts.Day_of_week = 'Thursday' THEN 4
            WHEN ts.Day_of_week = 'Friday' THEN 5
            WHEN ts.Day_of_week = 'Saturday' THEN 6
            ELSE 7
        END, ts.Start_time;

    OPEN cur
    FETCH NEXT FROM cur INTO 
        @DayOfWeek, @StartTime, @EndTime, @RoomNumber, @BuildingName, @DegreeProgram, @Semester, @Section

    WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT '--------------------------------------------------'
        PRINT 'Degree Program  : ' + @DegreeProgram
        PRINT 'Semester        : ' + @Semester
        PRINT 'Section         : ' + @Section
        PRINT 'Day             : ' + @DayOfWeek
        PRINT 'Start Time      : ' + @StartTime
        PRINT 'End Time        : ' + @EndTime
        PRINT 'Classroom       : Room ' + CAST(@RoomNumber AS VARCHAR) + ', ' + @BuildingName
        PRINT '--------------------------------------------------'

        FETCH NEXT FROM cur INTO 
            @DayOfWeek, @StartTime, @EndTime, @RoomNumber, @BuildingName, @DegreeProgram, @Semester, @Section
    END

    CLOSE cur
    DEALLOCATE cur
END


-- *****************************************************

EXEC ViewTimetableDetails_Print 
    @DegreeProgramName = 'BS Computer Science', 
    @SemesterName = 'Spring 2025', 
    @SectionName = 'A';

-- ******************************************************



-------------------------------------------------------------------------------------------------------------------------------------------------------


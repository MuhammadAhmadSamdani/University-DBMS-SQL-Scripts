﻿-- ================================================
-- VIEW 1: Student Full Info + Fee Status
-- ================================================
-- This view combines personal, academic, enrollment, and fee data.
-- It also indicates whether the student has paid or not.

-- Create the View: view_StudentFullDetails
CREATE VIEW view_StudentFullDetails AS
SELECT 
    SPD.Student_personal_id,
    SPD.Full_Name,
    SPD.Gender,
    SPD.Contact_phone,
    SUD.Student_Roll_Number,
    SUD.Current_Semester,
    SUD.Status,
    SUD.Uni_Email AS University_Email,
    SUD.Degree_Program_id,
    SUD.Section_id,
    FEE.Fee_amount,
    FEE.Final_Fee,
    FEE.Due_date,
    CASE 
        WHEN FEE.Final_Fee IS NULL THEN 'N/A'
        WHEN FEE.Final_Fee = 0 THEN ' Not Paid'
        ELSE ' Paid'
    END AS Payment_Remark
FROM 
    Student_Personal_Details SPD
JOIN 
    Student_University_Details SUD ON SPD.Student_personal_id = SUD.Student_personal_id
LEFT JOIN 
    Fee FEE ON SUD.Student_id = FEE.Student_id;


-- View data:
SELECT * FROM view_StudentFullDetails;


-- ================================================
-- VIEW 2: Faculty Complete Profile
-- ================================================
-- This view joins personal, university, salary and attendance details.

CREATE VIEW view_FacultyCompleteInfo AS
SELECT 
    FUD.Faculty_id,                            -- From Faculty_University_Details
    FPD.Full_Name,                             -- Computed from Faculty_Personal_Details
    FPD.Contact_Email AS Faculty_Email,        -- Computed Email
    FPD.Gender,
    FPD.Nationality,
    FPD.CNIC,
    FUD.Designation,
    FUD.Status AS Employment_Status,
    FUD.Department_id,
    SAL.Salary_Month,
    SAL.Base_Salary,
    SAL.Bonus,
    SAL.Deduction,
    SAL.Total_Salary,
    ATT.Attendance_Date,
    ATT.Attendance_Status
FROM 
    Faculty_University_Details FUD
JOIN 
    Faculty_Personal_Details FPD ON FUD.Faculty_personal_id = FPD.Faculty_personal_id
LEFT JOIN 
    Faculty_Salary SAL ON FUD.Faculty_id = SAL.Faculty_id
LEFT JOIN 
    Faculty_Attendance ATT ON FUD.Faculty_id = ATT.Faculty_id;


-- View data:
SELECT * FROM view_FacultyCompleteInfo;


-- ================================================
-- VIEW 3: Staff Complete Profile
-- ================================================
-- This view covers all essential data of a staff member.

CREATE VIEW view_StaffCompleteInfo AS
SELECT 
    SUD.Staff_id,                                -- From Staff_University_Details
    SPD.Full_Name,                               -- Computed from First_name + Last_name
    SPD.Gender,
    SPD.Contact_phone AS Staff_Contact,          -- Computed column
    SUD.Designation,
    SUD.Staff_Type,
    SUD.Status AS Employment_Status,
    SAL.Salary_Month,
    SAL.Base_Salary,
    SAL.Bonus,
    SAL.Deduction,
    SAL.Total_Salary,
    ATT.Attendance_Date,
    ATT.Attendance_Status
FROM 
    Staff_University_Details SUD
JOIN 
    Staff_Personal_Details SPD ON SUD.Staff_Personal_id = SPD.Staff_personal_id
LEFT JOIN 
    Staff_Salary SAL ON SUD.Staff_id = SAL.Staff_id
LEFT JOIN 
    Staff_Attendance ATT ON SUD.Staff_id = ATT.Staff_id;


-- View data:
SELECT * FROM view_StaffCompleteInfo;


-- ================================================
-- VIEW 4: Academic Structure Overview
-- ================================================
-- This view combines data from Departments, Courses, and Degree Programs.
-- It shows which department offers which degree and course.

CREATE VIEW view_AcademicStructure AS
SELECT 
    D.Department_name,                                      -- From Departments table
    DP.Degree_Program_name AS Degree_Program,               -- From Degree_Program table
    C.Course_title AS Course_Name,                          -- From Course table
    C.Credits AS Credit_Hours,
    CASE 
        WHEN C.Credits >= 3 THEN 'Core Course'
        ELSE 'Elective'
    END AS Course_Category
FROM 
    Departments D
JOIN 
    Degree_Program DP ON D.Department_id = DP.Department_id
JOIN 
    Course C ON DP.Degree_Program_id = C.Degree_Program_id;


-- View data:
SELECT * FROM view_AcademicStructure;





--------------------------------------------------
-- View to show students who haven't paid their fee
CREATE VIEW view_StudentsOutstandingFee AS
SELECT 
    SPD.Student_personal_id,
    SPD.Full_Name,
    SPD.Contact_phone,
    FEE.Fee_amount,
    FEE.Final_Fee,
    FEE.Due_date
FROM 
    Student_Personal_Details SPD
JOIN 
    Student_University_Details SUD ON SPD.Student_personal_id = SUD.Student_personal_id
JOIN 
    Fee FEE ON SUD.Student_id = FEE.Student_id
WHERE 
    FEE.Fee_amount > 0 AND FEE.Final_Fee IS NOT NULL
    AND FEE.Due_date < GETDATE();  -- Optionally filter for overdue


-- View data:
SELECT * FROM view_StudentsOutstandingFee;


-------------------------------------------------------
-- View to show high-salary faculty
CREATE VIEW view_HighSalaryFaculty AS
SELECT 
    FUD.Faculty_id,
    FPD.Full_Name,
    FPD.Contact_Email,
    SAL.Total_Salary AS Salary,
    SAL.Salary_Month
FROM 
    Faculty_Personal_Details FPD
JOIN 
    Faculty_University_Details FUD ON FPD.Faculty_personal_id = FUD.Faculty_personal_id
JOIN 
    Faculty_Salary SAL ON FUD.Faculty_id = SAL.Faculty_id
WHERE 
    SAL.Total_Salary > 100000;


-- View data:
SELECT * FROM view_HighSalaryFaculty;


-----------------------------------------------------------
-- View to show staff with perfect attendance
CREATE VIEW view_PerfectAttendanceStaff AS
SELECT 
    SUD.Staff_id,
    SPD.Full_Name,
    COUNT(ATT.Attendance_Status) AS Total_Days,
    COUNT(CASE WHEN ATT.Attendance_Status = 'Present' THEN 1 END) AS Present_Days
FROM 
    Staff_Personal_Details SPD
JOIN 
    Staff_University_Details SUD ON SPD.Staff_personal_id = SUD.Staff_Personal_id
JOIN 
    Staff_Attendance ATT ON SUD.Staff_id = ATT.Staff_id
GROUP BY 
    SUD.Staff_id, SPD.Full_Name
HAVING 
    COUNT(*) = COUNT(CASE WHEN ATT.Attendance_Status = 'Present' THEN 1 END);


-- View data:
SELECT * FROM view_PerfectAttendanceStaff;





-- View to show popular courses
CREATE VIEW view_PopularCourses AS
SELECT 
    C.Course_id,
    C.Course_title,
    COUNT(ES.Student_id) AS Enrolled_Students
FROM 
    Course C
JOIN 
    Enrolled_Students ES ON C.Degree_Program_id = ES.Degree_Program_id
GROUP BY 
    C.Course_id, C.Course_title
HAVING 
    COUNT(ES.Student_id) > 5;

-- View data:
SELECT * FROM view_PopularCourses;




-- View to list students in their final semester
CREATE VIEW view_FinalSemesterStudents AS
SELECT 
    SUD.Student_id,                   -- from Student_University_Details
    SPD.Full_Name,                   -- from Student_Personal_Details
    SUD.Current_Semester,            -- from Student_University_Details
    SUD.Section_id AS Section,       -- Section_id in Student_University_Details, aliased as Section
    SUD.Degree_Program_id AS Program -- Degree_Program_id in Student_University_Details, aliased as Program
FROM 
    Student_Personal_Details SPD
JOIN 
    Student_University_Details SUD ON SPD.Student_personal_id = SUD.Student_personal_id
WHERE 
    SUD.Current_Semester = 8;


-- View data:
SELECT * FROM view_FinalSemesterStudents;



	

------------------------------------------------------------------------------------------------------------------ STUDENT PERSONAL RECORD

-- Create Audit Table for Student Personal Details
CREATE TABLE Student_Personal_Audit (
    Audit_ID INT IDENTITY(1,1) PRIMARY KEY,
    Student_personal_id INT,
    First_name VARCHAR(100),
    Last_name VARCHAR(100),
    Full_Name NVARCHAR(201),
    Date_of_Birth DATE,
    Gender VARCHAR(10),
    Nationality VARCHAR(20),
    CNIC VARCHAR(50),
    Religion VARCHAR(20),
    Permanent_Address VARCHAR(100),
    Current_Address VARCHAR(100),
    City VARCHAR(50),
    Country VARCHAR(50),
    Student_Personal_email VARCHAR(50),
    Contact_Email NVARCHAR(100),
    Student_Personal_phone VARCHAR(10),
    Contact_phone NVARCHAR(13),
    Emergency_contact_name VARCHAR(20),
    Emergency_contact_relation VARCHAR(20),
    Emergency_contact_phone VARCHAR(10),
    Emergency_contact NVARCHAR(13),
    Action VARCHAR(10),
    Action_Date DATETIME DEFAULT GETDATE()
);

-- =====================================================================================================================================================

-- Trigger for INSERT
CREATE TRIGGER trg_StudentPersonalDetails_AfterInsert
ON Student_Personal_Details
AFTER INSERT
AS
BEGIN
    INSERT INTO Student_Personal_Audit (
        Student_personal_id, First_name, Last_name, Full_Name, Date_of_Birth, Gender, Nationality, CNIC, Religion, Permanent_Address, Current_Address,
        City, Country, Student_Personal_email, Contact_Email, Student_Personal_phone, Contact_phone, Emergency_contact_name,
        Emergency_contact_relation, Emergency_contact_phone, Emergency_contact,
        Action
    )
    SELECT
        Student_personal_id, First_name, Last_name, Full_Name, Date_of_Birth, Gender,  Nationality, CNIC, Religion, Permanent_Address, Current_Address,
		City, Country, Student_Personal_email, Contact_Email, Student_Personal_phone, Contact_phone, Emergency_contact_name,
        Emergency_contact_relation, Emergency_contact_phone, Emergency_contact,
        'INSERT'
    FROM INSERTED;
END;

-- =====================================================================================================================================================

-- Trigger for UPDATE

CREATE TRIGGER trg_StudentPersonalDetails_AfterUpdate
ON Student_Personal_Details
AFTER UPDATE
AS
BEGIN
     INSERT INTO Student_Personal_Audit (
        Student_personal_id, First_name, Last_name, Full_Name, Date_of_Birth, Gender, Nationality, CNIC, Religion, Permanent_Address, Current_Address,
        City, Country, Student_Personal_email, Contact_Email, Student_Personal_phone, Contact_phone, Emergency_contact_name,
        Emergency_contact_relation, Emergency_contact_phone, Emergency_contact,
        Action
    )
   SELECT
        Student_personal_id, First_name, Last_name, Full_Name, Date_of_Birth, Gender,  Nationality, CNIC, Religion, Permanent_Address, Current_Address,
		City, Country, Student_Personal_email, Contact_Email, Student_Personal_phone, Contact_phone, Emergency_contact_name,
        Emergency_contact_relation, Emergency_contact_phone, Emergency_contact,
        'UPDATE'
    FROM INSERTED;
END;


-- =====================================================================================================================================================

-- Trigger for DELETE

CREATE TRIGGER trg_StudentPersonalDetails_AfterDelete
ON Student_Personal_Details
AFTER DELETE
AS
BEGIN
    INSERT INTO Student_Personal_Audit (
        Student_personal_id, First_name, Last_name, Full_Name, Date_of_Birth, Gender, Nationality, CNIC, Religion, Permanent_Address,
        Current_Address, City, Country, Student_Personal_email, Contact_Email, Student_Personal_phone, Contact_phone,Emergency_contact_name,
        Emergency_contact_relation, Emergency_contact_phone, Emergency_contact,
        Action
    )
    SELECT
        Student_personal_id, First_name, Last_name, Full_Name, Date_of_Birth,Gender, Nationality, CNIC, Religion, Permanent_Address,
        Current_Address,City, Country,Student_Personal_email, Contact_Email, Student_Personal_phone, Contact_phone, Emergency_contact_name,
        Emergency_contact_relation, Emergency_contact_phone, Emergency_contact,
        'DELETE'
    FROM DELETED;
END;

----------------------------------------------------------------------------------------------------------------------------------------------
-- Sample Run Queries

-- Insert a student
INSERT INTO Student_Personal_Details ( First_name, Last_name, Date_of_Birth, Gender, Nationality,CNIC, Religion, Permanent_Address, Current_Address, City, 
			Country, Student_Personal_email, Student_Personal_phone, Emergency_contact_name, Emergency_contact_relation, Emergency_contact_phone)
VALUES ('Ahmad', 'Khan', '2000-01-15', 'Male', 'Pakistani','12345-6789012-3', 'Islam', '123 Main St', '456 Side St', 'Lahore', 'Pakistan',
		'ahmad.khan', '3001234567','Ali Khan', 'Father', '3007654321');

-- Update a student phone number ---------------------------------------------------------------
UPDATE Student_Personal_Details
SET Student_Personal_phone = '3007654322'
WHERE Student_personal_id = 1;

-- Delete a student ----------------------------------------------------------------------------
DELETE FROM Student_Personal_Details
WHERE Student_personal_id = 1;

-- Check audit logs ----------------------------------------------------------------------------
SELECT * FROM Student_Personal_Audit
ORDER BY Audit_ID;




-----------------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------------------------------------------- DEPARTMENT

-- Audit table to store changes (INSERT and DELETE) made on Departments table
CREATE TABLE Departments_Audit (
    Audit_ID INT IDENTITY(1,1) PRIMARY KEY,         
    Department_id INT,                              
    Department_name VARCHAR(50),                    
    Department_code VARCHAR(10),                    
    Head_of_department VARCHAR(50),                 
    Description VARCHAR(MAX),                       
    Email VARCHAR(50),                              
    Department_Email VARCHAR(100),                  
    Budget DECIMAL(18,2),                           
    Research VARCHAR(MAX),                          
    Action VARCHAR(10),                             
    Action_Date DATETIME DEFAULT GETDATE()          
);


---------------------------------------------------------------------------------------------------------

-- Trigger to log INSERT operations on Departments table
CREATE TRIGGER trg_Departments_AfterInsert
ON Departments
AFTER INSERT
AS
BEGIN
    -- Insert the new department details into the audit table with action 'INSERT'
    INSERT INTO Departments_Audit (Department_id, Department_name, Department_code, Head_of_department, Description,Email, Department_Email,Budget, Research,Action)
    SELECT
        Department_id, Department_name, Department_code, Head_of_department, Description, Email, Department_Email,
        Budget, Research,
        'INSERT'
    FROM INSERTED;
END;
GO

-----------------------------------------------------------------------------------------------------------------


-- Trigger to log DELETE operations on Departments table
CREATE TRIGGER trg_Departments_AfterDelete
ON Departments
AFTER DELETE
AS
BEGIN
    -- Insert the deleted department details into the audit table with action 'DELETE'
    INSERT INTO Departments_Audit (Department_id, Department_name, Department_code, Head_of_department, Description,Email, Department_Email,Budget, Research,Action)
    SELECT
        Department_id, Department_name, Department_code, Head_of_department, Description, Email, Department_Email,
        Budget, Research,
        'DELETE'
    FROM DELETED;
END;
GO


----------------------------------------------------------------------------------------------


INSERT INTO Departments (Department_name, Department_code, Head_of_department,  Description,Email, Budget, Research)
VALUES ( 'Computer Science','CS01', 'Dr. Ali', 'Department of Computer Science and Engineering','csdept', 1000000.00,'AI, Machine Learning');
GO

--------------------------------------------------------------------------


--  Sample Delete query
DELETE FROM Departments
WHERE Department_id = 2;
GO

--------------------------------------------------------------------------

--  Check Audit Log for Departments
SELECT * FROM Departments_Audit
ORDER BY Audit_ID;
GO

--------------------------------------------------------------------------



----------------------------------------------------------------------------------------------------------------- FEE

-- Audit table for logging insert and delete actions on Fee
CREATE TABLE Fee_Audit (
    Audit_ID INT PRIMARY KEY IDENTITY(1,1),
    Fee_id INT,
    Student_id INT,
    Semester_id INT,
    Fee_amount DECIMAL(10,2),
    Final_Fee DECIMAL(10,2),
    Due_date DATE,
    Action VARCHAR(10),
    Action_Date DATETIME DEFAULT GETDATE()
);



----------------------------------------------------- INSERT with Conditions and Rollback

-- Trigger to validate and audit Fee insertions
CREATE TRIGGER trg_Fee_AfterInsert
ON Fee
AFTER INSERT
AS
BEGIN
    BEGIN TRY
        -- Check constraints before proceeding
        IF EXISTS (SELECT 1 FROM INSERTED WHERE Fee_amount <= 0 OR Final_Fee <= 0 OR Final_Fee > Fee_amount)
        BEGIN
            -- Raise an error to stop insert
            RAISERROR('Invalid Fee values: Check Fee_amount and Final_Fee conditions.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- If validation passed, insert into audit table
        INSERT INTO Fee_Audit ( Fee_id, Student_id, Semester_id, Fee_amount, Final_Fee, Due_date, Action)
        SELECT
            Fee_id, Student_id, Semester_id, Fee_amount, Final_Fee, Due_date, 'INSERT'
        FROM INSERTED;
    END TRY

    BEGIN CATCH
        -- Handle unexpected errors
        ROLLBACK TRANSACTION;

        -- Optional: You can log the error here or re-throw it
        DECLARE @ErrMsg NVARCHAR(4000), @ErrSeverity INT;
        SELECT @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY();
        RAISERROR(@ErrMsg, @ErrSeverity, 1);
    END CATCH
END;

------------------------------------------------------------------ DELETE with Logging

-- Trigger to log deleted Fee records into audit
CREATE TRIGGER trg_Fee_AfterDelete
ON Fee
AFTER DELETE
AS
BEGIN
    INSERT INTO Fee_Audit (Fee_id, Student_id, Semester_id, Fee_amount, Final_Fee, Due_date, Action)
    SELECT
        Fee_id, Student_id, Semester_id, Fee_amount, Final_Fee, Due_date, 'DELETE'
    FROM DELETED;
END;


---------------------------------------------------

-- This will work
INSERT INTO Fee (Student_id, Semester_id, Fee_amount, Final_Fee, Due_date)
VALUES (1, 1, 50000, 45000, '2025-07-01');


-- This will trigger ROLLBACK (invalid Final_Fee > Fee_amount)
INSERT INTO Fee (Student_id, Semester_id, Fee_amount, Final_Fee, Due_date)
VALUES (1, 1, 50000, 55000, '2025-07-01');

--------------------------------------------------

SELECT * FROM Fee_Audit ORDER BY Audit_ID;

-------------------------------------------------

DELETE FROM Fee WHERE Fee_id = 1;

-------------------------------------------------
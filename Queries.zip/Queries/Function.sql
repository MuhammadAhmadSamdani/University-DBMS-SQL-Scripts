/****************************************************************************************
-- FUNCTIONS FOR Department
****************************************************************************************/

-- Step 1: Create the scalar function
CREATE FUNCTION dbo.fn_TotalDepartments()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Departments;  -- Make sure table name is correct
    RETURN @count;
END;
GO

-- Step 2: Run the function
SELECT dbo.fn_TotalDepartments() AS Total_Departments;
GO

-------------------------------------------------------------------------------------

-- Table-Valued Function: Returns departments by HOD name
CREATE FUNCTION dbo.fn_DepartmentsByHOD(@HODName NVARCHAR(100))
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Departments WHERE Head_of_department = @HODName
);
GO

-- Run command
SELECT * FROM dbo.fn_DepartmentsByHOD('Dr. Ali');
GO


/****************************************************************************************
-- FUNCTIONS FOR Exam
****************************************************************************************/

-- Scalar Function: Count of exams for a specific course
CREATE FUNCTION dbo.fn_ExamCountByCourse(@CourseID INT)
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Exam WHERE Course_ID = @CourseID;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_ExamCountByCourse(101) AS Exam_Count;
GO

-- Table-Valued Function: Returns exams held on a given date
CREATE FUNCTION dbo.fn_ExamsByDate(@ExamDate DATE)
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Exam WHERE Exam_Date = @ExamDate
);
GO

-- Run command
SELECT * FROM dbo.fn_ExamsByDate('2025-05-10');
GO


/****************************************************************************************
-- FUNCTIONS FOR Student_Scholarship
****************************************************************************************/

-- Scalar Function: Returns count of students on scholarship
CREATE FUNCTION dbo.fn_TotalScholarshipStudents()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Student_Scholarship;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_TotalScholarshipStudents() AS Total_Scholarship_Students;
GO

-- Table-Valued Function: Returns scholarships by type
CREATE FUNCTION dbo.fn_ScholarshipByType(@Type NVARCHAR(50))
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Scholarship WHERE Criteria = @Type
);
GO

-- Run command
SELECT * FROM dbo.fn_ScholarshipByType('Merit');
GO


/****************************************************************************************
-- FUNCTIONS FOR Courses
****************************************************************************************/

-- Scalar Function: Total number of courses
CREATE FUNCTION dbo.fn_TotalCourses()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Course;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_TotalCourses() AS Total_Courses;
GO

-- Table-Valued Function: Courses by degree program
CREATE FUNCTION dbo.fn_CoursesByDegree(@DegreeID INT)
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Course WHERE Degree_Program_id = @DegreeID
);
GO

-- Run command
SELECT * FROM dbo.fn_CoursesByDegree(3);
GO


/****************************************************************************************
-- FUNCTIONS FOR Degree_Program
****************************************************************************************/

-- Scalar Function: Total number of degree programs
CREATE FUNCTION dbo.fn_TotalDegreePrograms()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Degree_Program;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_TotalDegreePrograms() AS Total_Degree_Programs;
GO

-- Table-Valued Function: Programs by duration
CREATE FUNCTION dbo.fn_ProgramsByDuration(@Duration INT)
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Degree_Program WHERE Duration = @Duration
);
GO

-- Run command
SELECT * FROM dbo.fn_ProgramsByDuration(4);
GO


/****************************************************************************************
-- FUNCTIONS FOR Student_Personal_Details
****************************************************************************************/

-- Scalar Function: Total registered students
CREATE FUNCTION dbo.fn_TotalStudents()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Student_Personal_Details;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_TotalStudents() AS Total_Students;
GO

-- Table-Valued Function: Students by city
CREATE FUNCTION dbo.fn_StudentsByCity(@City NVARCHAR(100))
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Student_Personal_Details WHERE City = @City
);
GO

-- Run command
SELECT * FROM dbo.fn_StudentsByCity('Lahore');
GO


/****************************************************************************************
-- FUNCTIONS FOR Faculty_Personal_Details
****************************************************************************************/

-- Scalar Function: Total faculty members
CREATE FUNCTION dbo.fn_TotalFaculty()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Faculty_Personal_Details;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_TotalFaculty() AS Total_Faculty;
GO

-- Table-Valued Function: Faculty by qualification
CREATE FUNCTION dbo.fn_FacultyByQualification(@Gender NVARCHAR(100))
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Faculty_Personal_Details WHERE Gender = @Gender
);
GO

-- Run command
SELECT * FROM dbo.fn_FacultyByQualification('FeMale');
GO


/****************************************************************************************
-- FUNCTIONS FOR Faculty_University_Details
****************************************************************************************/

-- Scalar Function: Count faculty by department
CREATE FUNCTION dbo.fn_FacultyCountByDept(@DeptID INT)
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Faculty_University_Details WHERE Department_ID = @DeptID;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_FacultyCountByDept(2) AS Faculty_In_Dept;
GO

-- Table-Valued Function: Faculty by designation
CREATE FUNCTION dbo.fn_FacultyByDesignation(@Designation NVARCHAR(100))
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Faculty_University_Details WHERE Designation = @Designation
);
GO

-- Run command
SELECT * FROM dbo.fn_FacultyByDesignation('Assistant Professor');
GO


/****************************************************************************************
-- FUNCTIONS FOR Staff_Personal_Details
****************************************************************************************/

-- Scalar Function: Total staff
CREATE FUNCTION dbo.fn_TotalStaff()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Staff_Personal_Details;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_TotalStaff() AS Total_Staff;
GO

-- Table-Valued Function: Staff by gender
CREATE FUNCTION dbo.fn_StaffByGender(@Gender NVARCHAR(10))
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Staff_Personal_Details WHERE Gender = @Gender
);
GO

-- Run command
SELECT * FROM dbo.fn_StaffByGender('Male');
GO


/****************************************************************************************
-- FUNCTIONS FOR Staff_University_Details
****************************************************************************************/

-- Scalar Function: Count of staff in specific department
CREATE FUNCTION dbo.fn_StaffCountByDept(@Designation INT)
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Staff_University_Details WHERE Designation = @Designation;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_StaffCountByDept(5) AS Staff_In_Designation;
GO

-- Table-Valued Function: Staff by job title
CREATE FUNCTION dbo.fn_StaffByJobTitle(@Staff_Type NVARCHAR(100))
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Staff_University_Details WHERE Staff_Type = @Staff_Type
);
GO

-- Run command
SELECT * FROM dbo.fn_StaffByJobTitle('Electrician');
GO


/****************************************************************************************
-- FUNCTIONS FOR Admission_Application
****************************************************************************************/

-- Scalar Function: Total applications received
CREATE FUNCTION dbo.fn_TotalApplications()
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Admission_Application;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_TotalApplications() AS Total_Applications;
GO

-- Table-Valued Function: Applications by status
CREATE FUNCTION dbo.fn_ApplicationsByStatus(@Status NVARCHAR(50))
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Admission_Application WHERE Status = @Status
);
GO

-- Run command
SELECT * FROM dbo.fn_ApplicationsByStatus('Pending');
GO


/****************************************************************************************
-- FUNCTIONS FOR Student_University_Details
****************************************************************************************/

-- Scalar Function: Count of students enrolled in a specific semester
CREATE FUNCTION dbo.fn_StudentCountBySemester(@Semester NVARCHAR(50))
RETURNS INT
AS
BEGIN
    DECLARE @count INT;
    SELECT @count = COUNT(*) FROM Student_University_Details WHERE Current_Semester = @Semester;
    RETURN @count;
END;
GO

-- Run command
SELECT dbo.fn_StudentCountBySemester('Spring 2025') AS Students_In_Semester;
GO

-- Table-Valued Function: Students by batch
CREATE FUNCTION dbo.fn_StudentsByBatch(@Current_Semester INT)
RETURNS TABLE
AS
RETURN (
    SELECT * FROM Student_University_Details WHERE Current_Semester = @Current_Semester
);
GO

-- Run command
SELECT * FROM dbo.fn_StudentsByBatch(2);
GO

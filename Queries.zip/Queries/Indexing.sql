


--------------------------------------------------------------- Departments


-- Drop non-clustered index if already exists
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Departments_NonClustered')
    DROP INDEX IX_Departments_NonClustered ON Departments;

-- Create non-clustered index on Department_Name
CREATE NONCLUSTERED INDEX IX_Departments_NonClustered
ON Departments(Department_Name);

SET STATISTICS IO ON;
SELECT * FROM Departments WHERE Department_Name = 'Computer Science';
SET STATISTICS IO OFF;



--------------------------------------------------------------- Courses

-- Clustered Index

SET STATISTICS IO ON;
SELECT * FROM Course WHERE Course_ID = 1;
SET STATISTICS IO OFF;

-- Non-Clustered Index
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Course_NonClustered')
    DROP INDEX IX_Course_NonClustered ON Courses;
CREATE NONCLUSTERED INDEX IX_Courses_NonClustered ON Course(Course_title);

SET STATISTICS IO ON;
SELECT * FROM Course WHERE Course_title = 'DBMS';
SET STATISTICS IO OFF;



--------------------------------------------------------------- Degree_Program

SET STATISTICS IO ON;
SELECT * FROM Degree_Program WHERE Degree_Program_id = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Degree_Program_NonClustered')
    DROP INDEX IX_Degree_Program_NonClustered ON Degree_Program;
CREATE NONCLUSTERED INDEX IX_Degree_Program_NonClustered ON Degree_Program(Degree_Program_name);

SET STATISTICS IO ON;
SELECT * FROM Degree_Program WHERE Degree_Program_name = 'BSCS';
SET STATISTICS IO OFF;




--------------------------------------------------------------- Student_Personal_Details

SET STATISTICS IO ON;
SELECT * FROM Student_Personal_Details WHERE Student_personal_id = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Student_Personal_NonClustered')
    DROP INDEX IX_Student_Personal_NonClustered ON Student_Personal_Details;
CREATE NONCLUSTERED INDEX IX_Student_Personal_NonClustered ON Student_Personal_Details(Full_Name);

SET STATISTICS IO ON;
SELECT * FROM Student_Personal_Details WHERE Full_Name = 'Ali';
SET STATISTICS IO OFF;





--------------------------------------------------------------- Faculty_Personal_Details


SET STATISTICS IO ON;
SELECT * FROM Faculty_Personal_Details WHERE Faculty_personal_id = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Faculty_Personal_NonClustered')
    DROP INDEX IX_Faculty_Personal_NonClustered ON Faculty_Personal_Details;
CREATE NONCLUSTERED INDEX IX_Faculty_Personal_NonClustered ON Faculty_Personal_Details(Full_Name);

SET STATISTICS IO ON;
SELECT * FROM Faculty_Personal_Details WHERE Full_Name = 'Dr. Ahsan';
SET STATISTICS IO OFF;




--------------------------------------------------------------- Faculty_University_Details


SET STATISTICS IO ON;
SELECT * FROM Faculty_University_Details WHERE Faculty_ID = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Faculty_University_NonClustered')
    DROP INDEX IX_Faculty_University_NonClustered ON Faculty_University_Details;
CREATE NONCLUSTERED INDEX IX_Faculty_University_NonClustered ON Faculty_University_Details(Designation);

SET STATISTICS IO ON;
SELECT * FROM Faculty_University_Details WHERE Designation = 'Assistant Professor';
SET STATISTICS IO OFF;



--------------------------------------------------------------- Staff_Personal_Details


SET STATISTICS IO ON;
SELECT * FROM Staff_Personal_Details WHERE Staff_personal_id = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Staff_Personal_NonClustered')
    DROP INDEX IX_Staff_Personal_NonClustered ON Staff_Personal_Details;
CREATE NONCLUSTERED INDEX IX_Staff_Personal_NonClustered ON Staff_Personal_Details(Full_Name);

SET STATISTICS IO ON;
SELECT * FROM Staff_Personal_Details WHERE Full_Name = 'Zahid';
SET STATISTICS IO OFF;




--------------------------------------------------------------- Staff_University_Details



SET STATISTICS IO ON;
SELECT * FROM Staff_University_Details WHERE Staff_ID = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Staff_University_NonClustered')
    DROP INDEX IX_Staff_University_NonClustered ON Staff_University_Details;
CREATE NONCLUSTERED INDEX IX_Staff_University_NonClustered ON Staff_University_Details(Designation);

SET STATISTICS IO ON;
SELECT * FROM Staff_University_Details WHERE Designation = 'Admin Assistant';
SET STATISTICS IO OFF;





--------------------------------------------------------------- Admission_Application



SET STATISTICS IO ON;
SELECT * FROM Admission_Application WHERE Application_ID = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Admission_Application_NonClustered')
    DROP INDEX IX_Admission_Application_NonClustered ON Admission_Application;
CREATE NONCLUSTERED INDEX IX_Admission_Application_NonClustered ON Admission_Application(Status);

SET STATISTICS IO ON;
SELECT * FROM Admission_Application WHERE Status = 'Submitted';
SET STATISTICS IO OFF;





--------------------------------------------------------------- Student_University_Details



SET STATISTICS IO ON;
SELECT * FROM Student_University_Details WHERE Student_ID = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Student_University_NonClustered')
    DROP INDEX IX_Student_University_NonClustered ON Student_University_Details;
CREATE NONCLUSTERED INDEX IX_Student_University_NonClustered ON Student_University_Details(Student_Roll_Number);

SET STATISTICS IO ON;
SELECT * FROM Student_University_Details WHERE Student_Roll_Number = 'CS1234';
SET STATISTICS IO OFF;




--------------------------------------------------------------- Book_Category


SET STATISTICS IO ON;
SELECT * FROM Book_Category WHERE Category_ID = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Book_Category_NonClustered')
    DROP INDEX IX_Book_Category_NonClustered ON Book_Category;
CREATE NONCLUSTERED INDEX IX_Book_Category_NonClustered ON Book_Category(Category_Name);

SET STATISTICS IO ON;
SELECT * FROM Book_Category WHERE Category_Name = 'Technology';
SET STATISTICS IO OFF;




--------------------------------------------------------------- Library_Books



SET STATISTICS IO ON;
SELECT * FROM Library_Book WHERE Book_ID = 1;
SET STATISTICS IO OFF;

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Library_Book_NonClustered')
    DROP INDEX IX_Library_Book_NonClustered ON Library_Book;
CREATE NONCLUSTERED INDEX IX_Library_Book_NonClustered ON Library_Book(Title);

SET STATISTICS IO ON;
SELECT * FROM Library_Book WHERE Title = 'Database Systems';
SET STATISTICS IO OFF;


-------------------------------------------------------------------------------------------------------










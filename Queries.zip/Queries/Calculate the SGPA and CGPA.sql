
----------------------------------- To Set The Grades ----------------------------------

CREATE FUNCTION dbo.fn_GradeToPoint (@grade CHAR(1))
RETURNS FLOAT
AS
BEGIN
    RETURN 
        CASE @grade
            WHEN 'A' THEN 4.0
			WHEN '-A' THEN 3.7
			WHEN 'B+' THEN 3.3
            WHEN 'B' THEN 3
			WHEN 'B-' THEN 2.7
            WHEN 'C+' THEN 2.3
			WHEN 'C' THEN 2
			WHEN 'C-' THEN 1.7
            WHEN 'D' THEN 1.0
            WHEN 'F' THEN 0.0
            ELSE NULL -- for invalid grade
        END;
END;


------------------------------------------------------------- To Find Semester GPA --------------------------------------------------

DECLARE @Student_id INT = 3;  -- input student id
DECLARE @Semester_id INT = 1; -- input semester id

SELECT
    spd.Full_Name AS Student_Name,
    sud.Student_Roll_Number,
    d.Department_name,
    sem.Semester_name,
    AVG(dbo.fn_GradeToPoint(cr.Grade)) AS SGPA
FROM
    Course_results cr
    INNER JOIN Enrolled_Students es ON cr.Enrollment_id = es.Enrollment_id
    INNER JOIN Student_University_Details sud ON es.Student_id = sud.Student_id
    INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
    INNER JOIN Semester sem ON es.Semester_id = sem.Semester_id
    INNER JOIN Departments d ON sud.Department_id = d.Department_id
WHERE
    es.Student_id = @Student_id
    AND es.Semester_id = @Semester_id
    AND cr.Semester_id = @Semester_id
GROUP BY
    spd.Full_Name,
    sud.Student_Roll_Number,
    d.Department_name,
    sem.Semester_name;

-----------------------------------------------------------------------------------------------------------



---------------------------------------------- To Find CGPA -------------------------------------------

DECLARE @Student_id INT = 3;  -- Input student

SELECT 
    spd.Full_Name AS Student_Name,
    sud.Student_Roll_Number,
    d.Department_name,
    sem.Semester_name AS Current_Semester,
    AVG(dbo.fn_GradeToPoint(cr.Grade)) AS CGPA
FROM 
    Course_results cr
    INNER JOIN Enrolled_Students es ON cr.Enrollment_id = es.Enrollment_id
    INNER JOIN Student_University_Details sud ON es.Student_id = sud.Student_id
    INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
    INNER JOIN Departments d ON sud.Department_id = d.Department_id
    INNER JOIN Semester sem ON sud.Current_Semester = sem.Semester_id
WHERE
    es.Student_id = @Student_id
GROUP BY
    spd.Full_Name,
    sud.Student_Roll_Number,
    d.Department_name,
    sem.Semester_name;

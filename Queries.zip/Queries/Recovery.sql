
------------------------------------------------------------------- RECOVERY --------------------------------------------------------

-- Restore FULL backup (NORECOVERY to allow further restore)
RESTORE DATABASE UniversityManagementSystem
FROM DISK = 'C:\Backups\UniversityManagementSystem_Full.bak'
WITH NORECOVERY;  
GO

-- Restore DIFFERENTIAL backup
RESTORE DATABASE UniversityManagementSystem
FROM DISK = 'C:\Backups\UniversityManagementSystem_Diff.bak'
WITH RECOVERY;  -- Completes the restore
GO


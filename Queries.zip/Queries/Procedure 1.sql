﻿
------------------------------------------------------------------------------ ACADEMIC DATA -------------------------------------------

CREATE PROCEDURE AddAcademicData
    -- Departments
    @Department_name VARCHAR(50),
    @Department_code VARCHAR(10),
    @Head_of_department VARCHAR(50),
    @Description VARCHAR(MAX),
    @Email VARCHAR(50),
    @Budget DECIMAL(18,2),
    @Research VARCHAR(MAX),

    -- Degree Program
    @Degree_Program_name VARCHAR(50),
    @Degree_Program_code VARCHAR(10),
    @Degree_level VARCHAR(20),
    @Credits INT,
    @Duration INT,
    @Degree_Description VARCHAR(MAX),

    -- Course
    @Course_code VARCHAR(10),
    @Course_title VARCHAR(50),
    @Course_Type VARCHAR(10),
    @Course_Credits INT,
    @Course_Description VARCHAR(MAX),
    @Prerequisites VARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        
        IF EXISTS (SELECT 1 FROM Departments WHERE Department_code = @Department_code)
        BEGIN
            RAISERROR(' Department with this code already exists.', 16, 1);
            RETURN;
        END

        IF EXISTS (SELECT 1 FROM Degree_Program WHERE Degree_Program_code = @Degree_Program_code)
        BEGIN
            RAISERROR(' Degree Program with this code already exists.', 16, 1);
            RETURN;
        END

        IF EXISTS (SELECT 1 FROM Course WHERE Course_code = @Course_code)
        BEGIN
            RAISERROR(' Course with this code already exists.', 16, 1);
            RETURN;
        END

        IF @Degree_level NOT IN ('Diploma', 'Bachelor', 'Master', 'PhD')
        BEGIN
            RAISERROR(' Invalid Degree Level.', 16, 1);
            RETURN;
        END

        IF @Course_Type NOT IN ('Lab', 'Theory', 'Lab & Theory')
        BEGIN
            RAISERROR(' Invalid Course Type.', 16, 1);
            RETURN;
        END

       
        BEGIN TRANSACTION;

        -- Insert Department
        INSERT INTO Departments (Department_name, Department_code, Head_of_department, Description, Email, Budget, Research)
        VALUES (@Department_name, @Department_code, @Head_of_department, @Description, @Email, @Budget, @Research);
        DECLARE @NewDepartmentID INT = SCOPE_IDENTITY();

        -- Insert Degree Program
        INSERT INTO Degree_Program (Degree_Program_name, Degree_Program_code, Department_id, Degree_level, Credits, Duration, Description)
        VALUES (@Degree_Program_name, @Degree_Program_code, @NewDepartmentID, @Degree_level, @Credits, @Duration, @Degree_Description);
        DECLARE @NewDegreeProgramID INT = SCOPE_IDENTITY();

        -- Insert Course
        INSERT INTO Course (Course_code, Course_title, Course_Type, Credits, Department_id, Degree_Program_id, Description, Prerequisites)
        VALUES (@Course_code, @Course_title, @Course_Type, @Course_Credits, @NewDepartmentID, @NewDegreeProgramID, @Course_Description, @Prerequisites);

        COMMIT;

        PRINT ' Data successfully inserted.';
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK;

        DECLARE @ErrMsg NVARCHAR(4000), @ErrSeverity INT, @ErrState INT;
        SELECT @ErrMsg = ERROR_MESSAGE(), @ErrSeverity = ERROR_SEVERITY(), @ErrState = ERROR_STATE();
        RAISERROR(@ErrMsg, @ErrSeverity, @ErrState);
    END CATCH
END;
GO


-------------------------------------------------------------------------------------------------------

-- Example EXEC calls for the stored procedure:

EXEC AddAcademicData
    @Department_name = 'Computer Science',
    @Department_code = 'CS',
    @Head_of_department = 'Dr. Ahmed',
    @Description = 'CS Dept',
    @Email = 'csdept',
    @Budget = 500000,
    @Research = 'AI, ML',

    @Degree_Program_name = 'BS Computer Science',
    @Degree_Program_code = 'BSCS',
    @Degree_level = 'Bachelor',
    @Credits = 136,
    @Duration = 4,
    @Degree_Description = 'Bachelor in CS',

    @Course_code = 'CS101',
    @Course_title = 'Intro to Programming',
    @Course_Type = 'Theory',
    @Course_Credits = 3,
    @Course_Description = 'C++ Basics',
    @Prerequisites = 'None';


---------------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------------- ADD FACULTY DATA ------------------------------------


CREATE PROCEDURE AddFacultyData
    -- Personal Details
    @First_name VARCHAR(100),
    @Last_name VARCHAR(100),
    @Date_of_Birth DATE,
    @Gender VARCHAR(10),
    @Nationality VARCHAR(20),
    @CNIC VARCHAR(50),
    @Religion VARCHAR(20),
    @Address VARCHAR(100),
    @City VARCHAR(50),
    @Country VARCHAR(50),
    @Faculty_Personal_email VARCHAR(50),
    @Faculty_Personal_phone VARCHAR(10),

    -- University Details
	@FacultyPersonalID INT,
    @Hire_date DATE,
    @Department_id INT,
    @Designation VARCHAR(50),
    @Status VARCHAR(20),

    -- Attendance
    @Attendance_Date DATE,
    @Attendance_Status VARCHAR(10),

    -- Salary
    @Salary_Month DATE,
    @Base_Salary DECIMAL(10,2),
    @Bonus DECIMAL(10,2),
    @Deduction DECIMAL(10,2)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        
        IF @Status NOT IN ('Active', 'On_leave', 'resigned', 'retired')
        BEGIN
            RAISERROR(' Invalid Faculty Status. Must be one of Active, On_leave, resigned, retired.', 16, 1);
            ROLLBACK; RETURN;
        END

       
        IF @Attendance_Status NOT IN ('Present', 'Absent', 'Late')
        BEGIN
            RAISERROR(' Invalid Attendance Status. Must be Present, Absent, or Late.', 16, 1);
            ROLLBACK; RETURN;
        END

        IF LEN(@Faculty_Personal_phone) <> 10 OR TRY_CAST(@Faculty_Personal_phone AS BIGINT) IS NULL
        BEGIN
            RAISERROR('❌ Faculty phone must be exactly 10 digits and numeric.', 16, 1);
            ROLLBACK; RETURN;
        END

              
        IF @Date_of_Birth > GETDATE()
        BEGIN
            RAISERROR('❌ Date of Birth cannot be in the future.', 16, 1);
            ROLLBACK; RETURN;
        END

        
        IF @Attendance_Date > GETDATE()
        BEGIN
            RAISERROR('❌ Attendance date cannot be in the future.', 16, 1);
            ROLLBACK; RETURN;
        END

        
        IF NOT EXISTS (SELECT 1 FROM Departments WHERE Department_id = @Department_id)
        BEGIN
            RAISERROR(' Department ID does not exist.', 16, 1);
            ROLLBACK; RETURN;
        END

        
        INSERT INTO Faculty_Personal_Details (First_name, Last_name, Date_of_Birth, Gender, Nationality,CNIC, Religion, Address, City, Country,
            Faculty_Personal_email, Faculty_Personal_phone)
        VALUES ( @First_name, @Last_name, @Date_of_Birth, @Gender, @Nationality,@CNIC, @Religion, @Address, @City, @Country,
            @Faculty_Personal_email, @Faculty_Personal_phone);

        DECLARE @NewFacultyPersonalID INT = SCOPE_IDENTITY();

        
        INSERT INTO Faculty_University_Details (Faculty_personal_id, Hire_date, Department_id, Designation, Status)
        VALUES ( @FacultyPersonalID, @Hire_date, @Department_id, @Designation, @Status);

        DECLARE @NewFacultyID INT = SCOPE_IDENTITY();

        
        INSERT INTO Faculty_Attendance (Faculty_id, Attendance_Date, Attendance_Status)
        VALUES (@NewFacultyID, @Attendance_Date, @Attendance_Status);

      
        INSERT INTO Faculty_Salary (Faculty_id, Salary_Month, Base_Salary, Bonus, Deduction)
        VALUES (@NewFacultyID, @Salary_Month, @Base_Salary, @Bonus, @Deduction);

        COMMIT;

        PRINT ' Faculty data successfully inserted.';

        SELECT 
            @NewFacultyPersonalID AS Faculty_Personal_ID,
            @NewFacultyID AS Faculty_ID;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK;

        DECLARE @ErrMsg NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR('❌ Error occurred: %s', 16, 1, @ErrMsg);
    END CATCH
END;
GO

---------------------------------------------------------------------------------------------------------------------------



---------------------------------------------------------------------------------------------------------------------------

EXEC AddFacultyData
    @First_name = 'Ali',
    @Last_name = 'Khan',
    @Date_of_Birth = '1985-05-15',
    @Gender = 'Male',
    @Nationality = 'Pakistani',
    @CNIC = '3520212345678',
    @Religion = 'Islam',
    @Address = '123 Street, Lahore',
    @City = 'Lahore',
    @Country = 'Pakistan',
    @Faculty_Personal_email = 'alikhan',
    @Faculty_Personal_phone = '3001234567',

	@FacultyPersonalID = 2,
    @Hire_date = '2010-09-01',
    @Department_id = 1,               -- Make sure Department with ID=1 exists
    @Designation = 'Assistant Professor',
    @Status = 'Active',

    @Attendance_Date = '2025-06-07',
    @Attendance_Status = 'Present',

    @Salary_Month = '2025-05-01',
    @Base_Salary = 80000.00,
    @Bonus = 5000.00,
    @Deduction = 2000.00;

---------------------------------------------------------------------------------------------------------------------------


	
----------------------------------------------------------ADD STAFF DATA  -------------------------------------------------

CREATE PROCEDURE AddStaffData
    -- Personal Details
    @First_name VARCHAR(100),
    @Last_name VARCHAR(100),
    @Date_of_Birth DATE,
    @Gender VARCHAR(10),
    @Nationality VARCHAR(20),
    @CNIC VARCHAR(50),
    @Religion VARCHAR(20),
    @Address VARCHAR(100),
    @City VARCHAR(50),
    @Country VARCHAR(50),
    @Staff_Personal_email VARCHAR(50),
    @Staff_Personal_phone VARCHAR(10),

    -- University Details
    @Hire_date DATE,
    @Designation VARCHAR(50),
    @Staff_Type VARCHAR(20),
    @Status VARCHAR(20),

    -- Attendance
    @Attendance_Date DATE,
    @Attendance_Status VARCHAR(10),

    -- Salary
    @Salary_Month DATE,
    @Base_Salary DECIMAL(10,2),
    @Bonus DECIMAL(10,2),
    @Deduction DECIMAL(10,2)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        
        IF @Staff_Type NOT IN ('Administrator', 'Security', 'Medical', 'Cleaning', 'Gardener', 'Electrician', 'IT')
        BEGIN
            RAISERROR(' Invalid Staff Type.', 16, 1);
            ROLLBACK TRANSACTION; RETURN;
        END

        
        IF @Status NOT IN ('Active', 'On_leave', 'resigned', 'retired')
        BEGIN
            RAISERROR(' Invalid Staff Status.', 16, 1);
            ROLLBACK TRANSACTION; RETURN;
        END

        
        IF @Attendance_Status NOT IN ('Present', 'Absent', 'Late')
        BEGIN
            RAISERROR(' Invalid Attendance Status.', 16, 1);
            ROLLBACK TRANSACTION; RETURN;
        END

        
        IF LEN(@Staff_Personal_phone) <> 10 OR TRY_CAST(@Staff_Personal_phone AS BIGINT) IS NULL
        BEGIN
            RAISERROR(' Phone must be 10 digits numeric.', 16, 1);
            ROLLBACK TRANSACTION; RETURN;
        END

        
        IF @Date_of_Birth > GETDATE()
        BEGIN
            RAISERROR(' Date of Birth cannot be in the future.', 16, 1);
            ROLLBACK TRANSACTION; RETURN;
        END

        
        IF @Attendance_Date > GETDATE()
        BEGIN
            RAISERROR(' Attendance Date cannot be in the future.', 16, 1);
            ROLLBACK TRANSACTION; RETURN;
        END

        

        -- Insert Staff Personal Details
        INSERT INTO Staff_Personal_Details ( First_name, Last_name, Date_of_Birth, Gender, Nationality,CNIC, Religion, Address, City, Country,
            Staff_Personal_email, Staff_Personal_phone)
        VALUES ( @First_name, @Last_name, @Date_of_Birth, @Gender, @Nationality,@CNIC, @Religion, @Address, @City, @Country,
            @Staff_Personal_email, @Staff_Personal_phone);

        DECLARE @NewStaffPersonalID INT = SCOPE_IDENTITY();

        -- Insert Staff University Details
        INSERT INTO Staff_University_Details ( Staff_Personal_id, Hire_date, Designation, Staff_Type, Status)
        VALUES ( @NewStaffPersonalID, @Hire_date, @Designation, @Staff_Type, @Status);

        DECLARE @NewStaffID INT = SCOPE_IDENTITY();

        -- Insert Staff Attendance
        INSERT INTO Staff_Attendance ( Staff_id, Attendance_Date, Attendance_Status)
        VALUES (@NewStaffID, @Attendance_Date, @Attendance_Status);

        -- Insert Staff Salary
        INSERT INTO Staff_Salary ( Staff_id, Salary_Month, Base_Salary, Bonus, Deduction)
        VALUES (@NewStaffID, @Salary_Month, @Base_Salary, @Bonus, @Deduction );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END

---------------------------------------------------------------------------------------------------------------------------



---------------------------------------------------------------------------------------------------------------------------

EXEC AddStaffData
    @First_name = 'Ali',
    @Last_name = 'Khan',
    @Date_of_Birth = '1985-05-10',
    @Gender = 'Male',
    @Nationality = 'Pakistani',
    @CNIC = '3520212345678',
    @Religion = 'Islam',
    @Address = '123 Street, Lahore',
    @City = 'Lahore',
    @Country = 'Pakistan',
    @Staff_Personal_email = 'alikhan',
    @Staff_Personal_phone = '0300123456',
    @Hire_date = '2010-06-01',
    @Designation = 'Senior Administrator',
    @Staff_Type = 'Administrator',
    @Status = 'Active',
    @Attendance_Date = '2025-06-08',
    @Attendance_Status = 'Present',
    @Salary_Month = '2025-06-01',
    @Base_Salary = 50000,
    @Bonus = 5000,
    @Deduction = 2000;


---------------------------------------------------------------------------------------------------------------------------



-------------------------------------------------------- BUILDING DATA ----------------------------------------------------

CREATE PROCEDURE AddBuildingData
    @Building_name VARCHAR(50),
    @Total_floors INT
AS
BEGIN
    SET NOCOUNT ON;

   
    IF @Building_name IS NULL OR LTRIM(RTRIM(@Building_name)) = ''
    BEGIN
        RAISERROR('Building name cannot be empty.', 16, 1);
        RETURN;
    END

    IF @Total_floors <= 0
    BEGIN
        RAISERROR('Total floors must be greater than zero.', 16, 1);
        RETURN;
    END

    
    INSERT INTO Building (Building_name, Total_floors)
    VALUES (@Building_name, @Total_floors);

    PRINT 'Building data inserted successfully.';
END;


---------------------------------------------------------------------------------------------------------------------------


EXEC AddBuildingData @Building_name = 'Main Campus', @Total_floors = 5;


---------------------------------------------------------------------------------------------------------------------------



-----------------------------------------------------------TIME TABLE DATA ------------------------------------------------


CREATE PROCEDURE AddFullTimetableEntry
    -- Classroom params
    @Room_number INT,
    @Building_id INT,
    @Capacity INT,
    @Facilities VARCHAR(50),
    -- Time_slots params
    @Day_of_week VARCHAR(10),
    @Start_time TIME,
    @End_time TIME,
    -- Timetable params
    @Section_id INT
AS
BEGIN
    SET NOCOUNT ON;

   
    IF @Room_number <= 0
    BEGIN
        RAISERROR('Room number must be greater than zero.', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM Building WHERE Building_id = @Building_id)
    BEGIN
        RAISERROR('Building_id does not exist.', 16, 1);
        RETURN;
    END

    IF @Capacity <= 0
    BEGIN
        RAISERROR('Capacity must be greater than zero.', 16, 1);
        RETURN;
    END

    
    IF @Day_of_week NOT IN ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
    BEGIN
        RAISERROR('Invalid day of week.', 16, 1);
        RETURN;
    END

    IF @Start_time >= @End_time
    BEGIN
        RAISERROR('Start time must be earlier than end time.', 16, 1);
        RETURN;
    END

   
    IF NOT EXISTS (SELECT 1 FROM Section WHERE Section_id = @Section_id)
    BEGIN
        RAISERROR('Section_id does not exist.', 16, 1);
        RETURN;
    END

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Insert into Classroom and get inserted Classroom_id
        DECLARE @NewClassroomID INT;
        INSERT INTO Classroom (Room_number, Building_id, Capacity, Facilitiies)
        VALUES (@Room_number, @Building_id, @Capacity, @Facilities);

        SET @NewClassroomID = SCOPE_IDENTITY();

        -- Insert into Time_slots and get inserted Time_slot_id
        DECLARE @NewTimeSlotID INT;
        INSERT INTO Time_slots (Day_of_week, Start_time, End_time)
        VALUES (@Day_of_week, @Start_time, @End_time);

        SET @NewTimeSlotID = SCOPE_IDENTITY();

        -- Insert into Timetable using inserted Classroom_id and Time_slot_id
        INSERT INTO Timetable (Section_id, Time_slot_id, Classroom_id)
        VALUES (@Section_id, @NewTimeSlotID, @NewClassroomID);

        COMMIT TRANSACTION;

        PRINT 'All records inserted successfully.';

    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000), @ErrorSeverity INT, @ErrorState INT;
        SELECT @ErrorMessage = ERROR_MESSAGE(), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;

---------------------------------------------------------------------------------------------------------------------------


EXEC AddFullTimetableEntry 
    @Room_number = 101, 
    @Building_id = 1, 
    @Capacity = 40, 
    @Facilities = 'Projector, AC',
    @Day_of_week = 'Monday', 
    @Start_time = '09:00', 
    @End_time = '10:30',
    @Section_id = 1;


---------------------------------------------------------------------------------------------------------------------------
	


------------------------------------------------------------SEMESTER DATA  ------------------------------------------------

CREATE PROCEDURE sp_InsertSemester
    @Semester_name VARCHAR(20),
    @Semester_code VARCHAR(10),
    @Academic_year INT,
    @Start_date DATE,
    @End_date DATE
AS
BEGIN
    SET NOCOUNT ON;

    
    IF @Semester_name IS NULL OR LTRIM(RTRIM(@Semester_name)) = ''
    BEGIN
        RAISERROR('Semester name cannot be empty.', 16, 1);
        RETURN;
    END

    IF @Semester_code IS NULL OR LTRIM(RTRIM(@Semester_code)) = ''
    BEGIN
        RAISERROR('Semester code cannot be empty.', 16, 1);
        RETURN;
    END

    IF @Academic_year < 2000 OR @Academic_year > 2100
    BEGIN
        RAISERROR('Academic year must be between 2000 and 2100.', 16, 1);
        RETURN;
    END

    IF @Start_date >= @End_date
    BEGIN
        RAISERROR('Start date must be earlier than end date.', 16, 1);
        RETURN;
    END

    INSERT INTO Semester (Semester_name, Semester_code, Academic_year, Start_date, End_date)
    VALUES (@Semester_name, @Semester_code, @Academic_year, @Start_date, @End_date);
END;

---------------------------------------------------------------------------------------------------------------------------

EXEC sp_InsertSemester
    @Semester_name = 'Fall 2025',
    @Semester_code = 'F25',
    @Academic_year = 2025,
    @Start_date = '2025-09-01',
    @End_date = '2025-12-31';

---------------------------------------------------------------------------------------------------------------------------

	

-----------------------------------------------------------------SECTION DATA --------------------------------------------

CREATE PROCEDURE sp_InsertSection
    @Section_name CHAR(1),
    @Semester_id INT
AS
BEGIN
    SET NOCOUNT ON;

    IF @Section_name NOT LIKE '[A-Za-z]'
    BEGIN
        RAISERROR('Section name must be a single alphabet character (A-Z or a-z).', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM Semester WHERE Semester_id = @Semester_id)
    BEGIN
        RAISERROR('Semester_id does not exist.', 16, 1);
        RETURN;
    END

    INSERT INTO Section (Section_name, Semester_id)
    VALUES (@Section_name, @Semester_id);
END;

---------------------------------------------------------------------------------------------------------------------------


EXEC sp_InsertSection
    @Section_name = 'B',
    @Semester_id = 1;


---------------------------------------------------------------------------------------------------------------------------
	









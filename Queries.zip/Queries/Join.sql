


------------------------------------------------------------------------------ JOINS ------------------------------------------------------------------

-- ******************************************************************************************************
--                                         DEPARTMENTS RECORDS
-- ******************************************************************************************************



-- Create Join To List Distinct Degrees Under Department -----------------------------------------------
SELECT DISTINCT 
    d.Department_name,
    dp.Degree_Program_name,
    dp.Degree_level,
    dp.Total_credits_required,
    dp.Duration_years
FROM Departments d
INNER JOIN Degree_Program dp ON d.Department_id = dp.Department_id
WHERE dp.Degree_Program_name = 'Bachelor of Computer Science'; 



-- Create Join To List All Courses Under That Degree ----------------------------------------------------
SELECT 
    c.Course_code,
    c.Course_title,
    c.Course_Type,
    c.Total_credits_required,
    c.Prerequisites
FROM Course c
INNER JOIN Degree_Program dp ON c.Degree_Program_id = dp.Degree_Program_id
WHERE dp.Degree_Program_name = 'Bachelor of Computer Science'; 



-- ******************************************************************************************************
--                                         STUDENTS RECORDS
-- ******************************************************************************************************


--  Create Join To List The All Student That Apply In University ----------------------------------------
SELECT 
    spd.Full_Name AS Student_Name,
    spd.Contact_Email AS Email,
    spd.Contact_phone AS Phone,
    gi.Full_Name AS Guardian_Name,
    gi.Contact_phone AS Guardian_Phone,
    dp.Degree_Program_name AS Degree_Program,
    aa.FSC_Marks,
    aa.Is_eligible,
    aa.Application_date,
    aa.Status
FROM Admission_Application aa
JOIN Student_Personal_Details spd ON aa.Student_personal_id = spd.Student_personal_id
JOIN Guardian_Information gi ON spd.Student_personal_id = gi.Student_personal_id
JOIN Degree_Program dp ON aa.Degree_Program_id = dp.Degree_Program_id;



-- Create Join To List The Student That Are Eligible ------------------------------------------------------
SELECT 
    spd.Full_Name AS Student_Name,
    spd.Contact_Email AS Email,
    spd.Contact_phone AS Phone,
    gi.Full_Name AS Guardian_Name,
    gi.Contact_phone AS Guardian_Phone,
    dp.Degree_Program_name AS Degree_Program,
    aa.FSC_Marks,
    aa.Is_eligible,
    aa.Application_date,
    aa.Status
FROM Admission_Application aa
JOIN Student_Personal_Details spd ON aa.Student_personal_id = spd.Student_personal_id
JOIN Guardian_Information gi ON spd.Student_personal_id = gi.Student_personal_id
JOIN Degree_Program dp ON aa.Degree_Program_id = dp.Degree_Program_id;
WHERE aa.Is_eligible = 'Eligible'



--  Create Join To List The Student That Are Not Eligible ----------------------------------------------------
SELECT 
    spd.Full_Name AS Student_Name,
    spd.Contact_Email AS Email,
    spd.Contact_phone AS Phone,
    gi.Full_Name AS Guardian_Name,
    gi.Contact_phone AS Guardian_Phone,
    dp.Degree_Program_name AS Degree_Program,
    aa.FSC_Marks,
    aa.Is_eligible,
    aa.Application_date,
    aa.Status
FROM Admission_Application aa
JOIN Student_Personal_Details spd ON aa.Student_personal_id = spd.Student_personal_id
JOIN Guardian_Information gi ON spd.Student_personal_id = gi.Student_personal_id
JOIN Degree_Program dp ON aa.Degree_Program_id = dp.Degree_Program_id;
WHERE aa.Is_eligible = 'Not Eligible'


--  Create Join To List The Student That Are Graduated ----------------------------------------------------------
SELECT 
    sud.Student_id,
    spd.Full_Name AS Student_Name,
    sud.Student_Roll_Number,
    sud.Student_Batch,
    dp.Degree_Program_name,
    d.Department_name,
    sud.Status
FROM Student_University_Details sud
INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
INNER JOIN Degree_Program dp ON sud.Degree_Program_id = dp.Degree_Program_id
INNER JOIN Departments d ON sud.Department_id = d.Department_id
WHERE sud.Status = 'Graduated';



--  Create Join To List The Student That have Scholarship ---------------------------------------------
SELECT 
    sud.Student_id,
    spd.Full_Name AS Student_Name,
    sch.Description AS Scholarship,
    sch.Amount AS Discount_Percent,
    ss.Application_date,
    ss.Award_date,
    ss.Status AS Scholarship_Status
FROM Student_Scholarship ss
INNER JOIN Student_University_Details sud ON ss.Student_id = sud.Student_id
INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
INNER JOIN Scholarship sch ON ss.Scholarship_id = sch.Scholarship_id;


--  Create Join To List The Student That paid Fee ------------------------------------------------------
SELECT 
    sud.Student_id,
    spd.Full_Name AS Student_Name,
    sm.Semester_name,
    f.Fee_amount,
    f.Final_Fee,
    f.Due_date,
    ISNULL(SUM(p.Amount_paid), 0) AS Total_Paid,
    CASE 
        WHEN ISNULL(SUM(p.Amount_paid), 0) >= f.Final_Fee THEN 'Paid'
        WHEN ISNULL(SUM(p.Amount_paid), 0) > 0 THEN 'Partial'
        ELSE 'Unpaid'
    END AS Payment_Status
FROM Fee f
INNER JOIN Student_University_Details sud ON f.Student_id = sud.Student_id
INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
INNER JOIN Semester sm ON f.Semester_id = sm.Semester_id
LEFT JOIN Payment p ON f.Fee_id = p.Fee_id
GROUP BY sud.Student_id, spd.Full_Name, sm.Semester_name, f.Fee_amount, f.Final_Fee, f.Due_date;



-- Create Join To Check Attendance Details By Student And Course.----------------------------------
SELECT 
    sud.Student_id,
    spd.Full_Name AS Student_Name,
    c.Course_title,
    COUNT(CASE WHEN sa.Attendance_Status = 'Present' THEN 1 END) AS Days_Present,
    COUNT(CASE WHEN sa.Attendance_Status = 'Absent' THEN 1 END) AS Days_Absent,
    COUNT(*) AS Total_Classes
FROM Student_Attendance sa
INNER JOIN Student_University_Details sud ON sa.Student_id = sud.Student_id
INNER JOIN Student_Personal_Details spd ON sud.Student_personal_id = spd.Student_personal_id
INNER JOIN Course c ON sa.Course_id = c.Course_id
GROUP BY sud.Student_id, spd.Full_Name, c.Course_title;




-- ******************************************************************************************************
--                                         FACULITY RECORDS
-- ******************************************************************************************************


-- Create Join To View Male Faculity Records -----------------------------------------------------------
SELECT 
    spd.Full_Name AS Staff_Name,
    spd.Gender,
    sud.Designation,
    sud.Staff_Type,
    fa.Attendance_Date,
    fa.Attendance_Status
FROM Faculty_Attendance fa
JOIN Faculty_University_Details sud ON fa.Faculty_id = sud.Faculty_id
JOIN Staff_Personal_Details spd ON sud.Staff_Personal_id = spd.Staff_Personal_id
WHERE spd.Gender = 'Male';


-- Create Join To View FeMale Faculity Records ------------------------------------------------------------
SELECT 
    spd.Full_Name AS Staff_Name,
    spd.Gender,
    sud.Designation,
    sud.Staff_Type,
    fa.Attendance_Date,
    fa.Attendance_Status
FROM Faculty_Attendance fa
JOIN Faculty_University_Details sud ON fa.Faculty_id = sud.Faculty_id
JOIN Staff_Personal_Details spd ON sud.Staff_Personal_id = spd.Staff_Personal_id
WHERE spd.Gender = 'Male';


-- Create Join to Check the Members Who Attendace Above or Equal To 75% ---------------------------------------
SELECT 
    spd.Full_Name AS Staff_Name,
    spd.Gender,
    sud.Designation,
    sud.Staff_Type,
    COUNT(CASE WHEN fa.Attendance_Status = 'Present' THEN 1 END) * 100.0 / COUNT(*) AS Attendance_Percentage
FROM Faculty_Attendance fa
JOIN Faculty_University_Details sud ON fa.Faculty_id = sud.Faculty_id
JOIN Staff_Personal_Details spd ON sud.Staff_Personal_id = spd.Staff_Personal_id
GROUP BY spd.Full_Name, spd.Gender, sud.Designation, sud.Staff_Type
HAVING COUNT(CASE WHEN fa.Attendance_Status = 'Present' THEN 1 END) * 100.0 / COUNT(*) >= 75;


-- Create Join to Check the Members Who Attendace Below To 75% ----------------------------------------------------
SELECT 
    spd.Full_Name AS Staff_Name,
    spd.Gender,
    sud.Designation,
    sud.Staff_Type,
    COUNT(CASE WHEN fa.Attendance_Status = 'Present' THEN 1 END) * 100.0 / COUNT(*) AS Attendance_Percentage
FROM Faculty_Attendance fa
JOIN Faculty_University_Details sud ON fa.Faculty_id = sud.Faculty_id
JOIN Staff_Personal_Details spd ON sud.Staff_Personal_id = spd.Staff_Personal_id
GROUP BY spd.Full_Name, spd.Gender, sud.Designation, sud.Staff_Type
HAVING COUNT(CASE WHEN fa.Attendance_Status = 'Present' THEN 1 END) * 100.0 / COUNT(*) < 75;

















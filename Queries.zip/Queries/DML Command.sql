-- ============================================
-- Student_Personal_Details Table
-- ============================================

-- UPDATE: Change student contact number
UPDATE Student_Personal_Details
SET Contact_No = '03111234567'
WHERE Student_ID = 101;

-- DELETE: Delete student with null name
DELETE FROM Student_Personal_Details
WHERE Full_Name IS NULL;

-- ALTER: Add Blood_Group column
ALTER TABLE Student_Personal_Details
ADD Blood_Group VARCHAR(10);

-- ============================================
-- Faculty_Personal_Details Table
-- ============================================

-- UPDATE: Update faculty email
UPDATE Faculty_Personal_Details
SET Email = 'professor123@university.edu'
WHERE Faculty_ID = 202;

-- DELETE: Remove retired faculty
DELETE FROM Faculty_Personal_Details
WHERE Retirement_Status = 'Retired';

-- ALTER: Add Emergency_Contact column
ALTER TABLE Faculty_Personal_Details
ADD Emergency_Contact VARCHAR(15);

-- ============================================
-- Faculty_University_Details Table
-- ============================================

-- UPDATE: Assign department to faculty
UPDATE Faculty_University_Details
SET Department_ID = 5
WHERE Faculty_ID = 202;

-- DELETE: Remove resigned faculty
DELETE FROM Faculty_University_Details
WHERE Employment_Status = 'Resigned';

-- ALTER: Add Joining_Date column
ALTER TABLE Faculty_University_Details
ADD Joining_Date DATE;

-- ============================================
-- Staff_Personal_Details Table
-- ============================================

-- UPDATE: Change staff address
UPDATE Staff_Personal_Details
SET Address = 'New Staff Housing Block'
WHERE Staff_ID = 301;

-- DELETE: Remove terminated staff
DELETE FROM Staff_Personal_Details
WHERE Employment_Status = 'Terminated';

-- ALTER: Add CNIC column
ALTER TABLE Staff_Personal_Details
ADD CNIC VARCHAR(15);

-- ============================================
-- Staff_University_Details Table
-- ============================================

-- UPDATE: Promote staff designation
UPDATE Staff_University_Details
SET Designation = 'Senior Clerk'
WHERE Staff_ID = 301;

-- DELETE: Delete staff who resigned before 2015
DELETE FROM Staff_University_Details
WHERE Resignation_Date < '2015-01-01';

-- ALTER: Add Performance_Score column
ALTER TABLE Staff_University_Details
ADD Performance_Score INT;

-- ============================================
-- Admission_Application Table
-- ============================================

-- UPDATE: Mark admission as reviewed
UPDATE Admission_Application
SET Status = 'Reviewed'
WHERE Application_ID = 1001;

-- DELETE: Delete rejected applications
DELETE FROM Admission_Application
WHERE Status = 'Rejected';

-- ALTER: Add Reviewer_Comments column
ALTER TABLE Admission_Application
ADD Reviewer_Comments NVARCHAR(255);

-- ============================================
-- Student_University_Details Table
-- ============================================

-- UPDATE: Change current semester
UPDATE Student_University_Details
SET Current_Semester = 6
WHERE Student_ID = 101;

-- DELETE: Remove students marked as withdrawn
DELETE FROM Student_University_Details
WHERE Status = 'Withdrawn';

-- ALTER: Add Last_Updated_By column
ALTER TABLE Student_University_Details
ADD Last_Updated_By NVARCHAR(50);

-- ============================================
-- Enrollment Table
-- ============================================

-- UPDATE: Update grade for a student
UPDATE Enrollment
SET Grade = 'A+'
WHERE Student_ID = 101 AND Course_ID = 'CS101';

-- DELETE: Remove enrollment for dropped course
DELETE FROM Enrollment
WHERE Status = 'Dropped';

-- ALTER: Add Enrollment_Date column
ALTER TABLE Enrollment
ADD Enrollment_Date DATE;

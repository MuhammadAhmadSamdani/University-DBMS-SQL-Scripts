

----------------------------------------------------------STUDENT COMPLETE DETAILS ------------------------------------------------


CREATE PROCEDURE sp_InsertStudentCompleteDetails
(
    -- Student_Personal_Details params
    @First_name VARCHAR(100),
    @Last_name VARCHAR(100),
    @Date_of_Birth DATE,
    @Gender VARCHAR(10),
    @Nationality VARCHAR(20),
    @CNIC VARCHAR(50),
    @Religion VARCHAR(20),
    @Permanent_Address VARCHAR(100),
    @Current_Address VARCHAR(100),
    @City VARCHAR(50),
    @Country VARCHAR(50),
    @Student_Personal_email VARCHAR(50),
    @Student_Personal_phone VARCHAR(10),
    @Emergency_contact_name VARCHAR(20),
    @Emergency_contact_relation VARCHAR(20),
    @Emergency_contact_phone VARCHAR(10),

    -- Guardian_Information params
    @Guardian_First_name VARCHAR(100),
    @Guardian_Last_name VARCHAR(100),
    @Relationship VARCHAR(20),
    @Guardian_CNIC VARCHAR(50),
    @Guardian_Email VARCHAR(50),
    @Guardian_Phone_number VARCHAR(10),
    @Occupation VARCHAR(50),
    @Gaurdian_Address VARCHAR(100),

    -- Admission_Application params
    @Degree_Program_id INT,
    @FSC INT,
    @Application_date DATE,
    @Status VARCHAR(20),
    @Comments VARCHAR(MAX)
)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF EXISTS (SELECT 1 FROM Student_Personal_Details WHERE Student_Personal_email = @Student_Personal_email)
        BEGIN
            RAISERROR ('Error: Student email already exists.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF EXISTS (SELECT 1 FROM Student_Personal_Details WHERE Student_Personal_phone = @Student_Personal_phone)
        BEGIN
            RAISERROR ('Error: Student phone number already exists.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF EXISTS (SELECT 1 FROM Student_Personal_Details WHERE CNIC = @CNIC)
        BEGIN
            RAISERROR ('Error: Student CNIC already exists.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF EXISTS (SELECT 1 FROM Guardian_Information WHERE Email = @Guardian_Email)
        BEGIN
            RAISERROR ('Error: Guardian email already exists.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF EXISTS (SELECT 1 FROM Guardian_Information WHERE Phone_number = @Guardian_Phone_number)
        BEGIN
            RAISERROR ('Error: Guardian phone number already exists.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        IF EXISTS (SELECT 1 FROM Guardian_Information WHERE CNIC = @Guardian_CNIC)
        BEGIN
            RAISERROR ('Error: Guardian CNIC already exists.', 16, 1);
            ROLLBACK TRANSACTION;
            RETURN;
        END

        -- Insert into Student_Personal_Details
        INSERT INTO Student_Personal_Details
        (First_name, Last_name, Date_of_Birth, Gender, Nationality, CNIC, Religion, Permanent_Address, Current_Address, City, Country,
         Student_Personal_email, Student_Personal_phone, Emergency_contact_name, Emergency_contact_relation, Emergency_contact_phone)
        VALUES
        (@First_name, @Last_name, @Date_of_Birth, @Gender, @Nationality, @CNIC, @Religion,@Permanent_Address, @Current_Address, @City, @Country,
          @Student_Personal_email, @Student_Personal_phone,@Emergency_contact_name, @Emergency_contact_relation, @Emergency_contact_phone);

        DECLARE @NewStudentPersonalID INT = SCOPE_IDENTITY();

        -- Insert into Guardian_Information
        INSERT INTO Guardian_Information
        (Student_personal_id, First_name, Last_name, Relationship, CNIC, Email, Phone_number, Occupation, Gaurdian_Address )
        VALUES
        ( @NewStudentPersonalID, @Guardian_First_name, @Guardian_Last_name, @Relationship, @Guardian_CNIC, @Guardian_Email, @Guardian_Phone_number, @Occupation, @Gaurdian_Address);

        -- Insert into Admission_Application
        INSERT INTO Admission_Application
        ( Student_personal_id, Degree_Program_id, FSC, Application_date, Status, Comments )
        VALUES
        ( @NewStudentPersonalID, @Degree_Program_id, @FSC, @Application_date, @Status, @Comments );

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;


---------------------------------------------------------------------------------------------------------------------------

EXEC sp_InsertStudentCompleteDetails
    @First_name = 'Ali',
    @Last_name = 'Khan',
    @Date_of_Birth = '2000-05-15',
    @Gender = 'Male',
    @Nationality = 'Pakistani',
    @CNIC = '3520213345678',
    @Religion = 'Islam',
    @Permanent_Address = '123 Street, Lahore',
    @Current_Address = '456 Street, Lahore',
    @City = 'Lahore',
    @Country = 'Pakistan',
    @Student_Personal_email = 'ahmd.khan',
    @Student_Personal_phone = '03801234567',
    @Emergency_contact_name = 'Sara Khan',
    @Emergency_contact_relation = 'Sister',
    @Emergency_contact_phone = '03097654321',

    @Guardian_First_name = 'Ali',
    @Guardian_Last_name = 'Khan',
    @Relationship = 'Father',
    @Guardian_CNIC = '3520212345659',
    @Guardian_Email = 'ali.khan',
    @Guardian_Phone_number = '03009576543',
    @Occupation = 'Businessman',
    @Gaurdian_Address = '123 Street, Lahore',

    @Degree_Program_id = 1,
    @FSC = 650,
    @Application_date = '2025-06-01',
    @Status = 'Submitted',
    @Comments = 'Application submitted on time.'

---------------------------------------------------------------------------------------------------------------------------



-------------------------------------------------------------STUDENT UNIVERSITY DETAILS -----------------------------------

CREATE PROCEDURE sp_InsertStudentUniversityDetails
    @Student_personal_id INT,
    @Student_Roll_Number VARCHAR(20),
    @Department_id INT,
    @Degree_Program_id INT,
    @Current_Semester INT,
    @Section_id INT,
    @Uni_Email VARCHAR(50),
    @Status VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        IF EXISTS (SELECT 1 FROM Student_University_Details WHERE Student_Roll_Number = @Student_Roll_Number)
        BEGIN
            RAISERROR('Roll Number already exists.', 16, 1);
            RETURN;
        END

        IF @Status NOT IN ('Active', 'In-active', 'Graduated', 'Drop out')
        BEGIN
            RAISERROR('Invalid Status. Allowed values: Active, In-active, Graduated, Drop out.', 16, 1);
            RETURN;
        END

        -- Insert data
        INSERT INTO Student_University_Details
        (Student_personal_id,Student_Roll_Number, Department_id, Degree_Program_id,Current_Semester,Section_id, Uni_Email,Status)
        VALUES
        (@Student_personal_id,@Student_Roll_Number, @Department_id,@Degree_Program_id, @Current_Semester, @Section_id,@Uni_Email, @Status);

    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;


---------------------------------------------------------------------------------------------------------------------------


EXEC sp_InsertStudentUniversityDetails
    @Student_personal_id = 2,
    @Student_Roll_Number = 'CS2025-001',
    @Department_id = 1,
    @Degree_Program_id = 1,
    @Current_Semester = 1,
    @Section_id = 1,
    @Uni_Email = 'ahmad.khan',
    @Status = 'Active';


---------------------------------------------------------------------------------------------------------------------------


----------------------------------------------------------ENROLLED STUDENT  -----------------------------------------------


CREATE PROCEDURE sp_InsertEnrolledStudent
    @Student_id INT,
    @Degree_Program_id INT,
    @Semester_id INT,
    @Section_id INT,
    @Enrollment_date DATE
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        -- Check if student is already enrolled for the same degree, semester, and section
        IF EXISTS (
            SELECT 1 FROM Enrolled_Students
            WHERE Student_id = @Student_id
              AND Degree_Program_id = @Degree_Program_id
              AND Semester_id = @Semester_id
              AND Section_id = @Section_id
        )
        BEGIN
            RAISERROR('Student is already enrolled for this degree, semester, and section.', 16, 1);
            RETURN;
        END

        -- Insert new enrollment record
        INSERT INTO Enrolled_Students
        ( Student_id,Degree_Program_id,Semester_id,Section_id,Enrollment_date)
        VALUES
        (@Student_id,@Degree_Program_id,@Semester_id,@Section_id,@Enrollment_date );
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;

---------------------------------------------------------------------------------------------------------------------------

EXEC sp_InsertEnrolledStudent
    @Student_id = 3,
    @Degree_Program_id = 1,
    @Semester_id = 1,
    @Section_id = 1,
    @Enrollment_date = '2025-06-08';

---------------------------------------------------------------------------------------------------------------------------



--------------------------------------------------------------FEE PAYMENT ------------------------------------------------


CREATE PROCEDURE sp_InsertFeeAndPayment
    @Student_id INT,
    @Semester_id INT,
    @Fee_amount DECIMAL(10,2),
    @Final_Fee DECIMAL(10,2),
    @Due_date DATE,
    @Amount_paid DECIMAL(10,2),
    @Payment_date DATETIME,
    @Payment_Status VARCHAR(20) 
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO Fee (Student_id, Semester_id, Fee_amount, Final_Fee, Due_date)
        VALUES (@Student_id, @Semester_id, @Fee_amount, @Final_Fee, @Due_date);

        DECLARE @NewFeeID INT = SCOPE_IDENTITY();

        INSERT INTO Payment (Student_id, Fee_id, Amount_paid, Payment_date, Status)
        VALUES (@Student_id, @NewFeeID, @Amount_paid, @Payment_date, @Payment_Status);

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;


---------------------------------------------------------------------------------------------------------------------------


EXEC sp_InsertFeeAndPayment
    @Student_id = 3,
    @Semester_id = 1,
    @Fee_amount = 15000.00,
    @Final_Fee = 14000.00,
    @Due_date = '2025-07-15',
    @Amount_paid = 14000.00,
    @Payment_date = '2025-07-15',
    @Payment_Status = 'Paid';

---------------------------------------------------------------------------------------------------------------------------




--------------------------------------------------------SCHOLARSHIP -------------------------------------------------------


CREATE PROCEDURE sp_InsertStudentScholarship
    @Student_id INT,
    @Scholarship_id INT,
    @Application_date DATE,
    @Award_date DATE,
    @Status VARCHAR(20) 
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        -- Check duplicate scholarship application for same student and scholarship
        IF EXISTS (
            SELECT 1 FROM Student_Scholarship
            WHERE Student_id = @Student_id AND Scholarship_id = @Scholarship_id
        )
        BEGIN
            RAISERROR('Scholarship already assigned to this student.', 16, 1);
            RETURN;
        END

        INSERT INTO Student_Scholarship (Student_id, Scholarship_id, Application_date, Award_date, Status)
        VALUES (@Student_id, @Scholarship_id, @Application_date, @Award_date, @Status);
    END TRY
    BEGIN CATCH
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
    END CATCH
END;

---------------------------------------------------------------------------------------------------------------------------


EXEC sp_InsertStudentScholarship
    @Student_id = 3,
    @Scholarship_id = 1,
    @Application_date = '2025-05-01',
    @Award_date = '2025-06-01',
    @Status = 'Awarded';

---------------------------------------------------------------------------------------------------------------------------



----------------------------------------------------------SCHOLARSHIP DETAILS ---------------------------------------------


CREATE PROCEDURE sp_InsertScholarship
    @Description VARCHAR(100),
    @Amount DECIMAL(10,2),
    @Criteria VARCHAR(100),
    @Application_deadline DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Validate Description
    IF @Description IS NULL OR LTRIM(RTRIM(@Description)) = ''
    BEGIN
        RAISERROR('Description cannot be empty.', 16, 1);
        RETURN;
    END

    -- Validate Application_deadline
    IF @Application_deadline < CAST(GETDATE() AS DATE)
    BEGIN
        RAISERROR('Application deadline cannot be in the past.', 16, 1);
        RETURN;
    END

    -- If all validations pass, insert the record
    INSERT INTO Scholarship (Description, Amount, Criteria, Application_deadline)
    VALUES (@Description, @Amount, @Criteria, @Application_deadline);
END;


---------------------------------------------------------------------------------------------------------------------------

EXEC sp_InsertScholarship
    @Description = 'Need-Based Scholarship',
    @Amount = 40.00,
    @Criteria = 'Family income less than $30,000',
    @Application_deadline = '2025-09-30';


---------------------------------------------------------------------------------------------------------------------------


-------------------------------------------------------------------EXAM DETAILS -------------------------------------------

CREATE PROCEDURE sp_InsertExam
    @Exam_type VARCHAR(10),
    @Course_id INT,
    @Section_id INT,
    @Semester_id INT,
    @Total_marks INT,
    @Passing_marks INT,
    @Exam_date DATE,
    @Start_time DATETIME,
    @End_time DATETIME,
    @Classroom_id INT,
    @Invigilator_id INT,
    @Status VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    -- Validations
    IF @Exam_type NOT IN ('Mid-term', 'Final')
    BEGIN
        RAISERROR('Exam_type must be either ''Mid-term'' or ''Final''.', 16, 1);
        RETURN;
    END

    IF @Status NOT IN ('Scheduled', 'Completed', 'Cancelled')
    BEGIN
        RAISERROR('Status must be ''Scheduled'', ''Completed'' or ''Cancelled''.', 16, 1);
        RETURN;
    END

    IF @Total_marks <= 0
    BEGIN
        RAISERROR('Total_marks must be greater than 0.', 16, 1);
        RETURN;
    END

    IF @Passing_marks < 0 OR @Passing_marks > @Total_marks
    BEGIN
        RAISERROR('Passing_marks must be between 0 and Total_marks.', 16, 1);
        RETURN;
    END

    IF @Exam_date IS NULL OR @Start_time IS NULL OR @End_time IS NULL
    BEGIN
        RAISERROR('Exam_date, Start_time and End_time cannot be NULL.', 16, 1);
        RETURN;
    END

    IF @Start_time >= @End_time
    BEGIN
        RAISERROR('Start_time must be earlier than End_time.', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM Course WHERE Course_id = @Course_id)
    BEGIN
        RAISERROR('Course_id does not exist.', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM Section WHERE Section_id = @Section_id)
    BEGIN
        RAISERROR('Section_id does not exist.', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM Semester WHERE Semester_id = @Semester_id)
    BEGIN
        RAISERROR('Semester_id does not exist.', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM Classroom WHERE Classroom_id = @Classroom_id)
    BEGIN
        RAISERROR('Classroom_id does not exist.', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM Faculty_University_Details WHERE Faculty_id = @Invigilator_id)
    BEGIN
        RAISERROR('Invigilator_id does not exist.', 16, 1);
        RETURN;
    END

    -- Insert statement with column names in one line
    INSERT INTO Exam (Exam_type, Course_id, Section_id, Semester_id, Total_marks, Passing_marks, Exam_date, Start_time,
	End_time, Classroom_id, Invigilator_id, Status)
    VALUES (@Exam_type, @Course_id, @Section_id, @Semester_id, @Total_marks, @Passing_marks, @Exam_date, @Start_time, 
	@End_time, @Classroom_id, @Invigilator_id, @Status);
END;

---------------------------------------------------------------------------------------------------------------------------


EXEC sp_InsertExam
    @Exam_type = 'Mid-term',
    @Course_id = 1,
    @Section_id = 1,
    @Semester_id = 1,
    @Total_marks = 100,
    @Passing_marks = 40,
    @Exam_date = '2025-10-15',
    @Start_time = '2025-10-15 09:00:00',
    @End_time = '2025-10-15 11:00:00',
    @Classroom_id = 1,
    @Invigilator_id = 3,
    @Status = 'Scheduled';


---------------------------------------------------------------------------------------------------------------------------




--------------------------------------------------------------- COURSE RESULT ---------------------------------------------

CREATE PROCEDURE sp_InsertCourseResult
    @Enrollment_id INT,
    @Course_id INT,
    @Marks_obtained FLOAT,
    @Grade CHAR(1)
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM Enrolled_Students WHERE Enrollment_id = @Enrollment_id)
    BEGIN
        RAISERROR('Invalid Enrollment_id. Enrollment does not exist.', 16, 1);
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM Course WHERE Course_id = @Course_id)
    BEGIN
        RAISERROR('Invalid Course_id. Course does not exist.', 16, 1);
        RETURN;
    END

    IF @Marks_obtained < 0 OR @Marks_obtained > 100
    BEGIN
        RAISERROR('Marks_obtained must be between 0 and 100.', 16, 1);
        RETURN;
    END

    IF @Grade NOT IN ('A','B','C','D','F','I','W') 
    BEGIN
        RAISERROR('Invalid Grade. Allowed values: A, B, C, D, F, I, W.', 16, 1);
        RETURN;
    END

    -- Insert data
    INSERT INTO Course_results (Enrollment_id, Course_id, Marks_obtained, Grade)
    VALUES (@Enrollment_id, @Course_id, @Marks_obtained, @Grade);
END;


---------------------------------------------------------------------------------------------------------------------------

EXEC sp_InsertCourseResult 
    @Enrollment_id = 3,
    @Course_id = 1,
    @Marks_obtained = 85.5,
    @Grade = 'A';

---------------------------------------------------------------------------------------------------------------------------




----------------------------------------------------------BOOK CATEGORY--------------------------------------------

CREATE PROCEDURE Insert_Book_Category
    @Category_name VARCHAR(100),
    @Description VARCHAR(MAX)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Book_Category WHERE Category_name = @Category_name)
    BEGIN
        RAISERROR('Category name already exists.', 16, 1);
        RETURN;
    END

    INSERT INTO Book_Category (Category_name, Description)
    VALUES (@Category_name, @Description);

    PRINT 'Category inserted successfully.';
END

---------------------------------------------------------------------------------------------------------------------------

EXEC Insert_Book_Category 
    @Category_name = 'Science Fiction',
    @Description = 'Books related to futuristic and scientific concepts';


---------------------------------------------------------------------------------------------------------------------------



---------------------------------------------------------------LIBRARY BOOK =====------------------------------------------

CREATE PROCEDURE Insert_Library_Book
    @Title VARCHAR(100),
    @Author VARCHAR(100),
    @Publisher VARCHAR(100),
    @Publication_Year INT,
    @Edition VARCHAR(50),
    @Category_id INT,
    @Total_Copies INT,
    @Available_Copies INT,
    @Status VARCHAR(20)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Book_Category WHERE Category_id = @Category_id)
    BEGIN
        RAISERROR('Invalid Category ID.', 16, 1);
        RETURN;
    END

    IF @Available_Copies > @Total_Copies
    BEGIN
        RAISERROR('Available copies cannot be more than total copies.', 16, 1);
        RETURN;
    END

    IF @Status NOT IN ('Available', 'Lost', 'Damaged')
    BEGIN
        RAISERROR('Invalid status. Must be Available, Lost, or Damaged.', 16, 1);
        RETURN;
    END

    INSERT INTO Library_Book (Title, Author, Publisher, Publication_Year, Edition, Category_id, Total_Copies, Available_Copies, Status)
    VALUES (@Title, @Author, @Publisher, @Publication_Year, @Edition, @Category_id, @Total_Copies, @Available_Copies, @Status);

    PRINT 'Library book inserted successfully.';
END

---------------------------------------------------------------------------------------------------------------------------


EXEC Insert_Library_Book
    @Title = 'Introduction to AI',
    @Author = 'John Smith',
    @Publisher = 'TechBooks Inc.',
    @Publication_Year = 2023,
    @Edition = '2nd',
    @Category_id = 1,  
    @Total_Copies = 10,
    @Available_Copies = 8,
    @Status = 'Available';


---------------------------------------------------------------------------------------------------------------------------





------------------------------------------------------------------BORROW AND RETURN ---------------------------------------

CREATE PROCEDURE SP_Borrow_And_Return_Book
    @Action VARCHAR(10),               
    @Book_id INT,
    @Student_id INT = NULL,
    @Borrowed_date DATE = NULL,
    @Return_date DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @Action = 'BORROW'
    BEGIN
        
        IF NOT EXISTS (SELECT 1 FROM Library_Book WHERE Book_id = @Book_id AND Available_Copies > 0)
        BEGIN
            RAISERROR('Book is not available or does not exist.', 16, 1);
            RETURN;
        END

        IF NOT EXISTS (SELECT 1 FROM Student_University_Details WHERE Student_id = @Student_id)
        BEGIN
            RAISERROR('Student does not exist.', 16, 1);
            RETURN;
        END

        INSERT INTO Book_Borrow (Book_id, Student_id, Borrowed_date, Return_date)
        VALUES (@Book_id, @Student_id, @Borrowed_date, NULL);

        UPDATE Library_Book
        SET Available_Copies = Available_Copies - 1
        WHERE Book_id = @Book_id;

        PRINT 'Book borrowed successfully.';
    END

    ELSE IF @Action = 'RETURN'
    BEGIN
        DECLARE @Borrow_id INT;

        SELECT @Borrow_id = Borrow_id
        FROM Book_Borrow
        WHERE Book_id = @Book_id AND Return_date IS NULL;

        IF @Borrow_id IS NULL
        BEGIN
            RAISERROR('No active borrow record found for this book.', 16, 1);
            RETURN;
        END

        -- Insert into Book_Returned
        INSERT INTO Book_Returned (Returned_date, Borrow_id, Book_id)
        VALUES (@Return_date, @Borrow_id, @Book_id);

        -- Update borrow table return date
        UPDATE Book_Borrow
        SET Return_date = @Return_date
        WHERE Borrow_id = @Borrow_id;

        -- Increment available copies
        UPDATE Library_Book
        SET Available_Copies = Available_Copies + 1
        WHERE Book_id = @Book_id;

        PRINT 'Book returned successfully.';
    END
    ELSE
    BEGIN
        RAISERROR('Invalid action. Use ''BORROW'' or ''RETURN''.', 16, 1);
    END
END;

---------------------------------------------------------------------------------------------------------------------------

EXEC SP_Borrow_And_Return_Book
    @Action = 'BORROW',
    @Book_id = 1,
    @Student_id = 3,
    @Borrowed_date ='2025-10-15';


---------------------------------------------------------------------------------------------------------------------------

EXEC SP_Borrow_And_Return_Book
    @Action = 'RETURN',
    @Book_id = 1,
    @Return_date = '2025-10-15';


---------------------------------------------------------------------------------------------------------------------------